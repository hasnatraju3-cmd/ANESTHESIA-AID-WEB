// Anesthesia Aid - Progressive Web App Core Engine
// 1-to-1 Parity with Android Native Application Architecture

const STORAGE_KEY_RECORDS = 'anesthesia_records_list';
const STORAGE_KEY_ACTIVE_ID = 'anesthesia_active_record_id';
const STORAGE_KEY_DOCTOR = 'anesthesia_doctor_profile';
const STORAGE_KEY_THEME = 'anesthesia_theme_mode';
const STORAGE_KEY_ACCENT = 'anesthesia_accent_color';
const STORAGE_KEY_CUSTOM_DRUGS = 'anesthesia_custom_drugs';

// Auth & PWA Storage Keys
const STORAGE_KEY_AUTH_STATE = 'anesthesia_auth_state';
const STORAGE_KEY_AUTH_USER = 'anesthesia_auth_user';
const STORAGE_KEY_PWA_DISMISSED = 'anesthesia_pwa_dismissed';

// Auth State Constants Matching Android AuthManager
const AUTH_STATE_ONBOARDING = 'ONBOARDING';
const AUTH_STATE_REGISTRATION = 'REGISTRATION';
const AUTH_STATE_PENDING_APPROVAL = 'PENDING_APPROVAL';
const AUTH_STATE_TRIAL_EXPIRED = 'TRIAL_EXPIRED';
const AUTH_STATE_AUTHENTICATED = 'AUTHENTICATED';

// Admin & Support Credentials Matching Android
const ADMIN_EMAILS = [
  "hasnatraju3@gmail.com",
  "tsalmanrahman55@gmail.com"
];
const SUPPORT_EMAIL = "hasnatraju3@gmail.com";
const BKASH_PERSONAL_NUMBER = "01538412111";

// Firebase Configuration (Matching google-services.json)
const firebaseConfig = {
  apiKey: "remixed-api-key",
  projectId: "remixed-project-id",
  authDomain: "remixed-project-id.firebaseapp.com",
  storageBucket: "remixed-project-id.appspot.com"
};

let firestoreDb = null;
try {
  if (typeof firebase !== 'undefined') {
    if (!firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
    }
    firestoreDb = firebase.firestore();
  }
} catch (e) {
  console.warn("Firestore initialization status:", e);
}

let currentAuthState = AUTH_STATE_ONBOARDING;
let currentAuthUser = null;


// Default Drug Catalog matching Android DoseCalculatorScreen
const DEFAULT_DRUG_CATALOG = [
  // Induction Agents
  { category: "Induction", name: "Propofol", dosePerKgMin: 1.5, dosePerKgMax: 2.5, unit: "mg", route: "IV", note: "Titrate slowly in elderly / ASA III-IV" },
  { category: "Induction", name: "Ketamine", dosePerKgMin: 1.0, dosePerKgMax: 2.0, unit: "mg", route: "IV", note: "Cardiovascular stability; bronchodilator" },
  { category: "Induction", name: "Thiopental Sodium", dosePerKgMin: 3.0, dosePerKgMax: 5.0, unit: "mg", route: "IV", note: "Neuroprotective; avoid in porphyria" },
  { category: "Induction", name: "Etomidate", dosePerKgMin: 0.2, dosePerKgMax: 0.3, unit: "mg", route: "IV", note: "Minimal hemodynamic changes" },
  
  // Opioids
  { category: "Opioids", name: "Fentanyl", dosePerKgMin: 1.0, dosePerKgMax: 2.0, unit: "mcg", route: "IV", note: "Onset 1-2 min, peak 3-5 min" },
  { category: "Opioids", name: "Morphine", dosePerKgMin: 0.08, dosePerKgMax: 0.12, unit: "mg", route: "IV", note: "Onset 15-20 min, duration 4-6 hrs" },
  { category: "Opioids", name: "Pethidine", dosePerKgMin: 0.5, dosePerKgMax: 1.0, unit: "mg", route: "IV", note: "Antishivering at 25mg bolus" },

  // Muscle Relaxants
  { category: "Muscle Relaxants", name: "Suxamethonium", dosePerKgMin: 1.0, dosePerKgMax: 1.5, unit: "mg", route: "IV", note: "RSI; duration 5-10 min" },
  { category: "Muscle Relaxants", name: "Rocuronium", dosePerKgMin: 0.6, dosePerKgMax: 1.2, unit: "mg", route: "IV", note: "0.6 intubation; 1.2 RSI" },
  { category: "Muscle Relaxants", name: "Atracurium", dosePerKgMin: 0.4, dosePerKgMax: 0.5, unit: "mg", route: "IV", note: "Hofmann elimination; histamine release" },
  { category: "Muscle Relaxants", name: "Vecuronium", dosePerKgMin: 0.08, dosePerKgMax: 0.1, unit: "mg", route: "IV", note: "Organ-independent maintenance 0.02 mg/kg" },

  // Reversal Agents
  { category: "Reversal", name: "Neostigmine + Glycopyrrolate", dosePerKgMin: 0.04, dosePerKgMax: 0.05, unit: "mg", route: "IV", note: "With Glycopyrrolate 0.01 mg/kg" },
  { category: "Reversal", name: "Sugammadex", dosePerKgMin: 2.0, dosePerKgMax: 4.0, unit: "mg", route: "IV", note: "2 mg/kg moderate; 4 mg/kg deep; 16 mg/kg RSI" },

  // Emergency & Vasopressors
  { category: "Emergency / Vasopressors", name: "Ephedrine", dosePerKgMin: 0.05, dosePerKgMax: 0.1, unit: "mg", route: "IV", note: "3-6 mg bolus; titrate to response" },
  { category: "Emergency / Vasopressors", name: "Atropine", dosePerKgMin: 0.01, dosePerKgMax: 0.02, unit: "mg", route: "IV", note: "Min 0.3mg to prevent paradoxical bradycardia" },
  { category: "Emergency / Vasopressors", name: "Phenylephrine", dosePerKgMin: 0.5, dosePerKgMax: 1.5, unit: "mcg", route: "IV", note: "50-100 mcg IV bolus for vasodilation" },

  // Antiemetics
  { category: "Antiemetics", name: "Ondansetron", dosePerKgMin: 0.08, dosePerKgMax: 0.12, unit: "mg", route: "IV", note: "Standard adult dose: 4 - 8 mg IV" },
  { category: "Antiemetics", name: "Dexamethasone", dosePerKgMin: 0.08, dosePerKgMax: 0.15, unit: "mg", route: "IV", note: "4 - 8 mg IV given at induction" }
];

// Factory to create a clean patient record matching Android FullAnesthesiaRecord
function createNewPatientRecord(customName = "") {
  const timestamp = Date.now();
  const todayStr = new Date().toISOString().split('T')[0];

  return {
    id: timestamp,
    // Particulars
    name: customName || `Patient #${Math.floor(Math.random() * 900 + 100)}`,
    age: 35,
    sex: "Male",
    weight: 60,
    height: 165,
    bg: "O+",
    reg: "",
    ward: "",
    doa: todayStr,
    date: todayStr,
    diagnosis: "",
    operation: "",
    asa: "ASA I",
    mallampati: "Class I",
    drughistory: "",
    comorbidities: [],
    comorbiditiesOther: "",
    
    // Investigations
    inv: {
      hb: "12.5",
      wbc: "7500",
      platelet: "250",
      pt: "12.0",
      aptt: "30.0",
      inr: "1.00",
      sgpt: "32",
      sgot: "28",
      alp: "85",
      bili: "0.8",
      albumin: "4.2",
      creatinine: "0.90",
      bun: "15",
      na: "138",
      k: "4.2",
      rbs: "6.5",
      hba1c: "5.8",
      tsh: "2.5",
      ft4: "1.2",
      cxr: "Normal bronchovascular markings",
      ecg: "Normal sinus rhythm",
      echo: "LVEF 60%, no RWMA",
      hbsag: "Negative",
      hcv: "Negative",
      hiv: "Negative"
    },

    // Technique
    tech: {
      attending: "Dr. Clinician",
      consultant: "Dr. Consultant",
      type: "GA",
      gaPremed: "Midazolam 1mg, Fentanyl 100mcg IV",
      gaInduction: "Propofol 120mg IV",
      gaRelaxant: "Rocuronium 50mg IV",
      gaEtt: "7.5 mm Cuffed Oral",
      gaDepth: "21 cm",
      gaCl: "Grade I",
      gaCircuit: "Circle System",
      gaVolatile: "Isoflurane 1.2%",
      timeAnesStart: "",
      timeSurgStart: "",
      timeSurgEnd: "",
      timeExtubate: "",
      regSpace: "L3-L4",
      regNeedle: "25G Quincke",
      regDrug: "0.5% Bupivacaine Heavy 3.0 mL",
      regAdjuvant: "",
      regLevel: "T6",
      regBromage: "Grade 4"
    },

    // Intra-op Logs
    vitals: [],
    drugs: [],
    gases: {
      o2: "2.0",
      n2o: "2.0",
      agent: "Isoflurane 1.2%"
    },
    ioLogs: [],
    recoveryNotes: ""
  };
}

let recordsList = [];
let activeRecord = null;
let doctorProfile = {
  name: "Dr. Clinician",
  phone: "",
  bmdc: "",
  email: "",
  institute: ""
};

// --- INITIALIZATION ---
document.addEventListener("DOMContentLoaded", () => {
  loadThemeAndAccent();
  loadDoctorProfile();
  loadRecords();
  registerServiceWorker();
  
  // Initialize Auth State (Matching Android AuthManager)
  initAuth();

  // Set default vitals time to current
  resetLogTimesToNow();

  // Initial calculation updates
  calculateBMIAndDoses();
  calcFluids();
  calcPumpRate();
  calcMABL();
});

// ========================================================
// AUTHENTICATION & PWA ENGINE (1-to-1 PARITY WITH ANDROID)
// ========================================================

function initAuth() {
  const savedUserStr = localStorage.getItem(STORAGE_KEY_AUTH_USER);
  const savedState = localStorage.getItem(STORAGE_KEY_AUTH_STATE) || AUTH_STATE_ONBOARDING;

  if (savedUserStr) {
    try {
      currentAuthUser = JSON.parse(savedUserStr);
    } catch (e) {
      currentAuthUser = null;
    }
  }

  if (currentAuthUser && (savedState === AUTH_STATE_AUTHENTICATED || savedState === AUTH_STATE_PENDING_APPROVAL || savedState === AUTH_STATE_TRIAL_EXPIRED)) {
    if (checkTrialExpired(currentAuthUser)) {
      setAppAuthState(AUTH_STATE_TRIAL_EXPIRED, currentAuthUser);
    } else if (currentAuthUser.account_status === 'APPROVED' || isAdminEmail(currentAuthUser.email)) {
      setAppAuthState(AUTH_STATE_AUTHENTICATED, currentAuthUser);
    } else if (currentAuthUser.account_status === 'PENDING') {
      setAppAuthState(AUTH_STATE_PENDING_APPROVAL, currentAuthUser);
    } else {
      setAppAuthState(AUTH_STATE_ONBOARDING, null);
    }
  } else {
    setAppAuthState(AUTH_STATE_ONBOARDING, null);
  }

  setupPwaInstallPrompt();
}

function isAdminEmail(email) {
  if (!email) return false;
  return ADMIN_EMAILS.includes(email.trim().toLowerCase());
}

function checkTrialExpired(user) {
  if (!user) return false;
  if (isAdminEmail(user.email)) return false;
  if (user.account_type === 'subscribed') return false;

  // 10-day trial limit matching Android AuthManager
  const startTime = user.trial_started_at || user.registration_timestamp || (user.registration_date ? new Date(user.registration_date).getTime() : Date.now());
  const tenDaysMs = 10 * 24 * 60 * 60 * 1000;
  return (Date.now() - startTime) > tenDaysMs;
}

function setAppAuthState(state, user = null) {
  currentAuthState = state;
  currentAuthUser = user;
  localStorage.setItem(STORAGE_KEY_AUTH_STATE, state);

  if (user) {
    localStorage.setItem(STORAGE_KEY_AUTH_USER, JSON.stringify(user));
    // Sync into doctorProfile for headers and reports
    doctorProfile.name = user.name || doctorProfile.name;
    doctorProfile.phone = user.phone || doctorProfile.phone;
    doctorProfile.bmdc = user.bmdc || doctorProfile.bmdc;
    doctorProfile.email = user.email || doctorProfile.email;
    doctorProfile.institute = user.institute || doctorProfile.institute;
    localStorage.setItem(STORAGE_KEY_DOCTOR, JSON.stringify(doctorProfile));
  } else if (state === AUTH_STATE_ONBOARDING) {
    localStorage.removeItem(STORAGE_KEY_AUTH_USER);
  }

  const authContainer = document.getElementById('auth-container');
  const mainAppContainer = document.getElementById('main-app-container');

  if (state === AUTH_STATE_AUTHENTICATED) {
    if (authContainer) authContainer.style.display = 'none';
    if (mainAppContainer) {
      mainAppContainer.style.display = 'flex';
      showScreen('screen-records');
    }
  } else {
    if (authContainer) authContainer.style.display = 'block';
    if (mainAppContainer) mainAppContainer.style.display = 'none';

    if (state === AUTH_STATE_PENDING_APPROVAL) {
      populatePendingScreen(user);
      showAuthScreen('screen-pending-approval');
    } else if (state === AUTH_STATE_TRIAL_EXPIRED) {
      showAuthScreen('screen-trial-expired');
    } else if (state === AUTH_STATE_REGISTRATION) {
      showAuthScreen('screen-registration');
    } else {
      showAuthScreen('screen-onboarding');
    }
  }
}

function showAuthScreen(screenId) {
  const screens = ['screen-onboarding', 'screen-registration', 'screen-pending-approval', 'screen-trial-expired'];
  screens.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = (id === screenId) ? 'flex' : 'none';
  });
}

function populatePendingScreen(user) {
  if (!user) return;
  const setEl = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val || '--';
  };
  setEl('pending-val-name', user.name);
  setEl('pending-val-email', user.email);
  setEl('pending-val-phone', user.phone);
  setEl('pending-val-inst', user.institute);
  setEl('pending-val-bmdc', user.bmdc);

  const rowTxn = document.getElementById('pending-row-txnid');
  const valTxn = document.getElementById('pending-val-txnid');
  if (user.bKashTxnId) {
    if (rowTxn) rowTxn.style.display = 'flex';
    if (valTxn) valTxn.textContent = user.bKashTxnId;
  } else {
    if (rowTxn) rowTxn.style.display = 'none';
  }
}

function toggleRegTypeUI() {
  const isSubscribed = document.getElementById('reg-type-subscribed')?.checked;
  const bkashBox = document.getElementById('reg-bkash-container');
  if (bkashBox) {
    bkashBox.style.display = isSubscribed ? 'block' : 'none';
  }
}

function handleCountryChange() {
  const country = getVal('reg-country');
  const bmdcInput = document.getElementById('reg-bmdc');
  if (bmdcInput) {
    if (country === 'Bangladesh') {
      bmdcInput.placeholder = 'A-XXXXX';
    } else {
      bmdcInput.placeholder = 'Medical License Reg No';
    }
  }
}

function copyBkashNumber(num = BKASH_PERSONAL_NUMBER) {
  navigator.clipboard.writeText(num).then(() => {
    showToast(`bKash number ${num} copied!`);
  }).catch(() => {
    showToast(`bKash number: ${num}`);
  });
}

async function submitRegistration() {
  const name = getVal('reg-name');
  const phone = getVal('reg-phone');
  const email = getVal('reg-email');
  const institute = getVal('reg-institute');
  const session = getVal('reg-session');
  const bmdc = getVal('reg-bmdc');
  const country = getVal('reg-country') || 'Bangladesh';
  const isSubscribed = document.getElementById('reg-type-subscribed')?.checked;
  const regType = isSubscribed ? 'subscribed' : 'trial';
  const txnId = isSubscribed ? getVal('reg-txnid').trim().toUpperCase() : '';

  // Input Validation matching Android RegistrationScreen
  if (!name.trim()) {
    alert("Please enter your Full Name.");
    return;
  }
  if (!phone.trim()) {
    alert("Please enter your Contact Phone Number.");
    return;
  }
  if (!email.trim() || !email.includes('@')) {
    alert("Please enter a valid Email Address.");
    return;
  }
  if (!institute.trim()) {
    alert("Please enter your Medical College / Institute.");
    return;
  }
  if (!bmdc.trim()) {
    alert("Please enter your BMDC / Medical License Reg No.");
    return;
  }
  if (isSubscribed && !txnId) {
    alert("Please enter your bKash Transaction ID (TxnID) after sending the fee.");
    return;
  }

  const cleanEmail = email.trim().toLowerCase();
  const isAdmin = isAdminEmail(cleanEmail);

  const newUser = {
    name: name.trim(),
    phone: phone.trim(),
    email: cleanEmail,
    institute: institute.trim(),
    session: session.trim(),
    bmdc: bmdc.trim(),
    country: country,
    account_type: regType,
    bKashTxnId: txnId,
    account_status: isAdmin ? 'APPROVED' : 'PENDING',
    registration_date: new Date().toISOString(),
    registration_timestamp: Date.now(),
    trial_started_at: Date.now(),
    last_active: new Date().toISOString()
  };

  const btn = document.getElementById('btn-submit-registration');
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Submitting...";
  }

  // Firestore Sync matching Android AuthManager
  if (firestoreDb) {
    try {
      await firestoreDb.collection("users").doc(cleanEmail).set(newUser, { merge: true });
      await firestoreDb.collection("notifications").add({
        title: "New Registration",
        message: `Dr. ${newUser.name} (${newUser.bmdc}) registered with ${regType} account.`,
        email: cleanEmail,
        createdAt: new Date().toISOString(),
        read: false
      });
    } catch (e) {
      console.warn("Firestore registration write notice:", e);
    }
  }

  if (btn) {
    btn.disabled = false;
    btn.textContent = "Submit Registration";
  }

  if (isAdmin) {
    alert("Admin recognized! Account instantly approved.");
    setAppAuthState(AUTH_STATE_AUTHENTICATED, newUser);
  } else {
    setAppAuthState(AUTH_STATE_PENDING_APPROVAL, newUser);
    showToast("Registration submitted successfully");
  }
}

function sendPendingSupportEmail() {
  const user = currentAuthUser || {};
  const subject = encodeURIComponent("Anesthesia Aid Account Verification Request");
  const body = encodeURIComponent(
    `Dear Admin,\n\nPlease verify my Anesthesia Aid account.\n\n` +
    `Doctor Name: ${user.name || '--'}\n` +
    `Email: ${user.email || '--'}\n` +
    `Phone: ${user.phone || '--'}\n` +
    `Institute: ${user.institute || '--'}\n` +
    `BMDC / License: ${user.bmdc || '--'}\n` +
    `Account Type: ${user.account_type || 'trial'}\n` +
    (user.bKashTxnId ? `bKash TxnID: ${user.bKashTxnId}\n` : '') +
    `\nThank you,\n${user.name || ''}`
  );
  window.location.href = `mailto:${SUPPORT_EMAIL}?subject=${subject}&body=${body}`;
}

function emailAdminDirect() {
  window.location.href = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent("Anesthesia Aid Support Inquiry")}`;
}

async function checkApprovalStatus() {
  if (!currentAuthUser || !currentAuthUser.email) {
    alert("No active user profile found.");
    return;
  }

  const btn = document.getElementById('btn-check-status');
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Checking...";
  }

  let approved = false;

  if (firestoreDb) {
    try {
      const doc = await firestoreDb.collection("users").doc(currentAuthUser.email.toLowerCase()).get();
      if (doc.exists) {
        const data = doc.data();
        currentAuthUser = { ...currentAuthUser, ...data };
        if (data.account_status === 'APPROVED' || isAdminEmail(currentAuthUser.email)) {
          approved = true;
        }
      }
    } catch (e) {
      console.warn("Firestore check error:", e);
    }
  }

  if (btn) {
    btn.disabled = false;
    btn.textContent = "🔄 Check Approval Status";
  }

  if (approved) {
    alert("Your account has been approved by the admin! Welcome to Anesthesia Aid.");
    setAppAuthState(AUTH_STATE_AUTHENTICATED, currentAuthUser);
  } else {
    alert("Your account is still under review by the administrator. Once verified, this screen will update automatically. You may also tap 'Email Admin Support' to expedite verification.");
  }
}

async function executeLogin() {
  const email = getVal('login-email').trim().toLowerCase();
  const phone = getVal('login-phone').trim();
  const errEl = document.getElementById('login-error-msg');

  if (errEl) errEl.style.display = 'none';

  if (!email || !email.includes('@')) {
    if (errEl) { errEl.textContent = "Please enter a valid registered Email."; errEl.style.display = 'block'; }
    return;
  }
  if (!phone) {
    if (errEl) { errEl.textContent = "Please enter your Contact Phone Number."; errEl.style.display = 'block'; }
    return;
  }

  const btn = document.getElementById('btn-login-confirm');
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Logging In...";
  }

  let user = null;

  if (firestoreDb) {
    try {
      const doc = await firestoreDb.collection("users").doc(email).get();
      if (doc.exists) {
        user = doc.data();
      }
    } catch (e) {
      console.warn("Firestore query warning:", e);
    }
  }

  // Fallback to locally cached user if offline
  if (!user && currentAuthUser && currentAuthUser.email === email) {
    user = currentAuthUser;
  }

  if (btn) {
    btn.disabled = false;
    btn.textContent = "Log In";
  }

  if (!user) {
    if (errEl) {
      errEl.textContent = "No account found with this Email. Please register a new account.";
      errEl.style.display = 'block';
    }
    return;
  }

  // Verify Phone match (matching Android AuthManager phone check)
  const cleanDbPhone = (user.phone || '').replace(/\D/g, '');
  const cleanInputPhone = phone.replace(/\D/g, '');
  const phoneMatches = cleanDbPhone.endsWith(cleanInputPhone) || cleanInputPhone.endsWith(cleanDbPhone);

  if (!phoneMatches && !isAdminEmail(email)) {
    if (errEl) {
      errEl.textContent = "Incorrect Contact Phone Number for this registered Email.";
      errEl.style.display = 'block';
    }
    return;
  }

  closeModal('modal-login');

  if (user.account_status === 'APPROVED' || isAdminEmail(user.email)) {
    if (checkTrialExpired(user)) {
      setAppAuthState(AUTH_STATE_TRIAL_EXPIRED, user);
    } else {
      setAppAuthState(AUTH_STATE_AUTHENTICATED, user);
      showToast("Logged in successfully");
    }
  } else if (user.account_status === 'REJECTED') {
    alert("Registration declined. Please contact support via email: " + SUPPORT_EMAIL);
  } else {
    setAppAuthState(AUTH_STATE_PENDING_APPROVAL, user);
  }
}

function switchToRegisterFromLogin() {
  closeModal('modal-login');
  showAuthScreen('screen-registration');
}

function signOutUser() {
  if (confirm("Are you sure you want to sign out and switch accounts?")) {
    setAppAuthState(AUTH_STATE_ONBOARDING, null);
    showToast("Signed out successfully");
  }
}

// --- PWA INSTALL PROMPT LOGIC ---
let deferredPwaInstallPrompt = null;

function setupPwaInstallPrompt() {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPwaInstallPrompt = e;

    const isDismissed = localStorage.getItem(STORAGE_KEY_PWA_DISMISSED);
    if (!isDismissed) {
      const banner = document.getElementById('pwa-install-banner');
      if (banner) banner.classList.add('active');
    }
  });

  // Check iOS Safari
  const isIos = /iphone|ipad|ipod/.test(window.navigator.userAgent.toLowerCase());
  const isStandalone = window.navigator.standalone === true || window.matchMedia('(display-mode: standalone)').matches;
  if (isIos && !isStandalone && !localStorage.getItem(STORAGE_KEY_PWA_DISMISSED)) {
    const banner = document.getElementById('pwa-install-banner');
    const iosBox = document.getElementById('ios-instruction-box');
    const installBtn = document.getElementById('pwa-install-btn');
    if (banner && iosBox) {
      iosBox.style.display = 'block';
      if (installBtn) installBtn.style.display = 'none';
      banner.classList.add('active');
    }
  }
}

function triggerPwaInstall() {
  if (deferredPwaInstallPrompt) {
    deferredPwaInstallPrompt.prompt();
    deferredPwaInstallPrompt.userChoice.then((choiceResult) => {
      if (choiceResult.outcome === 'accepted') {
        showToast("Anesthesia Aid installed successfully!");
      }
      deferredPwaInstallPrompt = null;
      dismissPwaPrompt();
    });
  } else {
    dismissPwaPrompt();
    showToast("Add to Home Screen from your browser menu");
  }
}

function dismissPwaPrompt() {
  const banner = document.getElementById('pwa-install-banner');
  if (banner) banner.classList.remove('active');
  localStorage.setItem(STORAGE_KEY_PWA_DISMISSED, 'true');
}


function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js')
      .then(() => console.log('Anesthesia Aid SW Active'))
      .catch(err => console.log('SW registration error:', err));
  }
}

function resetLogTimesToNow() {
  const now = new Date();
  const timeStr = now.toTimeString().substring(0, 5);
  ['v-time', 'drug-time-input', 'io-log-time'].forEach(id => {
    const el = document.getElementById(id);
    if (el && !el.value) el.value = timeStr;
  });
}

// --- DATA PERSISTENCE ---
function loadRecords() {
  const saved = localStorage.getItem(STORAGE_KEY_RECORDS);
  if (saved) {
    try {
      recordsList = JSON.parse(saved);
    } catch (e) {
      recordsList = [];
    }
  }

  if (!recordsList || recordsList.length === 0) {
    const defaultRec = createNewPatientRecord("Mr. John Doe");
    recordsList = [defaultRec];
    saveRecords();
  }

  const savedActiveId = localStorage.getItem(STORAGE_KEY_ACTIVE_ID);
  if (savedActiveId) {
    activeRecord = recordsList.find(r => r.id.toString() === savedActiveId.toString());
  }
  if (!activeRecord && recordsList.length > 0) {
    activeRecord = recordsList[0];
  }

  renderRecordsUI();
  populateActiveRecordToInputs();
}

function saveRecords() {
  localStorage.setItem(STORAGE_KEY_RECORDS, JSON.stringify(recordsList));
  if (activeRecord) {
    localStorage.setItem(STORAGE_KEY_ACTIVE_ID, activeRecord.id.toString());
  }
  renderRecordsUI();
}

function showToast(msg) {
  const toast = document.getElementById('toast');
  if (toast) {
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2000);
  }
}

// --- NAVIGATION & TABS ---
function showScreen(screenId) {
  // Hide all screens
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  
  // Show target screen
  const target = document.getElementById(screenId);
  if (target) target.classList.add('active');

  // Update tabs highlight
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  const tabMap = {
    'screen-records': 'tab-records',
    'screen-particulars': 'tab-particulars',
    'screen-investigations': 'tab-investigations',
    'screen-calculator': 'tab-calculator',
    'screen-technique': 'tab-technique',
    'screen-vitals': 'tab-vitals',
    'screen-drugs': 'tab-drugs',
    'screen-io': 'tab-io',
    'screen-summary': 'tab-summary'
  };
  const activeTabId = tabMap[screenId];
  if (activeTabId) {
    const tabEl = document.getElementById(activeTabId);
    if (tabEl) {
      tabEl.classList.add('active');
      tabEl.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  }

  // Toggle speed dial visibility (only on home screen)
  const fab = document.getElementById('speed-dial-container');
  if (fab) {
    fab.style.display = (screenId === 'screen-records') ? 'flex' : 'none';
  }

  // Refresh calculations or summary if navigating to them
  if (screenId === 'screen-calculator') {
    calculateBMIAndDoses();
    calcFluids();
  } else if (screenId === 'screen-summary') {
    renderSummarySheet();
  }
}

// --- TAB 1: HOME & PATIENT RECORDS ---
function renderRecordsUI() {
  const container = document.getElementById('records-list-container');
  const countEl = document.getElementById('records-count');
  const headerNameEl = document.getElementById('header-patient-name');
  const activeBanner = document.getElementById('active-patient-banner');
  const modalList = document.getElementById('modal-patient-list');

  if (countEl) countEl.textContent = recordsList.length;

  if (activeRecord) {
    if (headerNameEl) headerNameEl.textContent = `${activeRecord.name} (${activeRecord.age}y/${activeRecord.sex.charAt(0)})`;
    if (activeBanner) {
      activeBanner.style.display = 'block';
      const nameEl = document.getElementById('active-banner-name');
      const detailsEl = document.getElementById('active-banner-details');
      if (nameEl) nameEl.textContent = activeRecord.name;
      if (detailsEl) detailsEl.textContent = `${activeRecord.age}y / ${activeRecord.sex} (${activeRecord.weight} kg) | Surgery: ${activeRecord.operation || 'Not specified'}`;
    }
  }

  if (container) {
    container.innerHTML = '';
    recordsList.forEach(rec => {
      const isCurrent = activeRecord && activeRecord.id === rec.id;
      const card = document.createElement('div');
      card.className = `record-card ${isCurrent ? 'active' : ''}`;
      card.innerHTML = `
        <div style="flex:1;" onclick="selectPatientCase(${rec.id})">
          <div class="record-patient-name">${rec.name} ${isCurrent ? '<span style="color:var(--primary); font-size:0.75rem;">(Active)</span>' : ''}</div>
          <div class="record-meta">${rec.age}y / ${rec.sex} | ${rec.weight} kg | Reg: ${rec.reg || '--'}</div>
          <div class="record-meta" style="color:var(--primary); font-weight:600;">Surgery: ${rec.operation || 'Not specified'}</div>
        </div>
        <div style="display:flex; gap:6px; align-items:center;">
          <button class="btn btn-sm ${isCurrent ? 'btn-primary' : 'btn-secondary'}" onclick="selectPatientCase(${rec.id})">${isCurrent ? 'Current' : 'Select'}</button>
          <button class="btn-del" title="Delete Case" onclick="confirmDeletePatient(${rec.id})">🗑️</button>
        </div>
      `;
      container.appendChild(card);
    });
  }

  if (modalList) {
    modalList.innerHTML = '';
    recordsList.forEach(rec => {
      const isCurrent = activeRecord && activeRecord.id === rec.id;
      const item = document.createElement('div');
      item.className = `record-card ${isCurrent ? 'active' : ''}`;
      item.style.marginBottom = '6px';
      item.onclick = () => { selectPatientCase(rec.id); closeModal('modal-patient'); };
      item.innerHTML = `
        <div>
          <strong>${rec.name}</strong> (${rec.age}y/${rec.sex.charAt(0)})
          <div style="font-size:0.75rem; color:var(--on-surface-variant);">${rec.operation || 'No surgery specified'}</div>
        </div>
        <div>${isCurrent ? '✓' : ''}</div>
      `;
      modalList.appendChild(item);
    });
  }
}

function selectPatientCase(id) {
  const found = recordsList.find(r => r.id === id);
  if (found) {
    activeRecord = found;
    saveRecords();
    populateActiveRecordToInputs();
    renderRecordsUI();
    showToast(`Switched to ${activeRecord.name}`);
  }
}

function createNewCase() {
  const newRec = createNewPatientRecord();
  recordsList.unshift(newRec);
  activeRecord = newRec;
  saveRecords();
  populateActiveRecordToInputs();
  renderRecordsUI();
  showScreen('screen-particulars');
  showToast("Created new patient record");
}

function confirmDeletePatient(id) {
  if (confirm("Are you sure you want to delete this patient record?")) {
    recordsList = recordsList.filter(r => r.id !== id);
    if (activeRecord && activeRecord.id === id) {
      activeRecord = recordsList.length > 0 ? recordsList[0] : null;
    }
    saveRecords();
    populateActiveRecordToInputs();
    renderRecordsUI();
    showToast("Record deleted");
  }
}

function handleRecordSearch() {
  const query = document.getElementById('record-search-input').value.toLowerCase().trim();
  const cards = document.querySelectorAll('#records-list-container .record-card');
  cards.forEach(c => {
    const text = c.textContent.toLowerCase();
    c.style.display = text.includes(query) ? 'flex' : 'none';
  });
}

// --- POPULATE ACTIVE RECORD DATA TO FORM INPUTS ---
function populateActiveRecordToInputs() {
  if (!activeRecord) return;

  // Particulars
  setVal('p-name', activeRecord.name);
  setVal('p-age', activeRecord.age);
  setVal('p-sex', activeRecord.sex);
  setVal('p-bg', activeRecord.bg);
  setVal('p-weight', activeRecord.weight);
  setVal('p-height', activeRecord.height);
  setVal('p-reg', activeRecord.reg);
  setVal('p-ward', activeRecord.ward);
  setVal('p-doa', activeRecord.doa);
  setVal('p-date', activeRecord.date);
  setVal('p-diagnosis', activeRecord.diagnosis);
  setVal('p-operation', activeRecord.operation);
  setVal('p-asa', activeRecord.asa);
  setVal('p-mallampati', activeRecord.mallampati);
  setVal('p-drughistory', activeRecord.drughistory);
  setVal('p-comorbidities-other', activeRecord.comorbiditiesOther);

  // Co-morbidities chips
  const chipsContainer = document.getElementById('comorbidities-chips');
  if (chipsContainer) {
    chipsContainer.querySelectorAll('.chip-btn').forEach(btn => {
      const val = btn.getAttribute('data-val');
      if (activeRecord.comorbidities && activeRecord.comorbidities.includes(val)) {
        btn.classList.add('selected');
      } else {
        btn.classList.remove('selected');
      }
    });
    updateCoMorbiditiesCount();
  }

  // Investigations
  const inv = activeRecord.inv || {};
  setVal('inv-hb', inv.hb);
  setVal('inv-wbc', inv.wbc);
  setVal('inv-platelet', inv.platelet);
  setVal('inv-pt', inv.pt);
  setVal('inv-aptt', inv.aptt);
  setVal('inv-inr', inv.inr);
  setVal('inv-sgpt', inv.sgpt);
  setVal('inv-sgot', inv.sgot);
  setVal('inv-alp', inv.alp);
  setVal('inv-bili', inv.bili);
  setVal('inv-albumin', inv.albumin);
  setVal('inv-creatinine', inv.creatinine);
  setVal('inv-bun', inv.bun);
  setVal('inv-na', inv.na);
  setVal('inv-k', inv.k);
  setVal('inv-rbs', inv.rbs);
  setVal('inv-hba1c', inv.hba1c);
  setVal('inv-tsh', inv.tsh);
  setVal('inv-ft4', inv.ft4);
  setVal('inv-cxr', inv.cxr);
  setVal('inv-ecg', inv.ecg);
  setVal('inv-echo', inv.echo);
  updateSerologyChips(inv.hbsag, inv.hcv, inv.hiv);

  // Technique
  const tech = activeRecord.tech || {};
  setVal('tech-attending', tech.attending || doctorProfile.name);
  setVal('tech-consultant', tech.consultant);
  setVal('tech-type', tech.type || "GA");
  setVal('tech-ga-premed', tech.gaPremed);
  setVal('tech-ga-induction', tech.gaInduction);
  setVal('tech-ga-relaxant', tech.gaRelaxant);
  setVal('tech-ga-ett', tech.gaEtt);
  setVal('tech-ga-depth', tech.gaDepth);
  setVal('tech-ga-cl', tech.gaCl);
  setVal('tech-ga-circuit', tech.gaCircuit);
  setVal('tech-ga-volatile', tech.gaVolatile);
  setVal('tech-time-anes-start', tech.timeAnesStart);
  setVal('tech-time-surg-start', tech.timeSurgStart);
  setVal('tech-time-surg-end', tech.timeSurgEnd);
  setVal('tech-time-extubate', tech.timeExtubate);
  setVal('tech-reg-space', tech.regSpace);
  setVal('tech-reg-needle', tech.regNeedle);
  setVal('tech-reg-drug', tech.regDrug);
  setVal('tech-reg-adjuvant', tech.regAdjuvant);
  setVal('tech-reg-level', tech.regLevel);
  setVal('tech-reg-bromage', tech.regBromage);
  handleTechniqueTypeChange();

  // Gases
  const gases = activeRecord.gases || {};
  setVal('gas-o2', gases.o2 || "2.0");
  setVal('gas-n2o', gases.n2o || "2.0");
  setVal('gas-agent', gases.agent || "Isoflurane 1.2%");

  // Recovery notes
  setVal('sum-recovery-notes', activeRecord.recoveryNotes || "");

  // Render sub-tables
  renderVitalsTable();
  renderDrugsTable();
  renderIoTable();
  calculateBMIAndDoses();
}

function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = (val !== undefined && val !== null) ? val : "";
}

function getVal(id) {
  const el = document.getElementById(id);
  return el ? el.value.trim() : "";
}

// --- TAB 2: PARTICULARS AUTO-SAVE & CHIPS ---
function autoSaveParticulars() {
  if (!activeRecord) return;
  activeRecord.name = getVal('p-name') || "Unnamed Patient";
  activeRecord.age = parseInt(getVal('p-age')) || 35;
  activeRecord.sex = getVal('p-sex') || "Male";
  activeRecord.bg = getVal('p-bg') || "O+";
  activeRecord.weight = parseFloat(getVal('p-weight')) || 60;
  activeRecord.height = parseFloat(getVal('p-height')) || 165;
  activeRecord.reg = getVal('p-reg');
  activeRecord.ward = getVal('p-ward');
  activeRecord.doa = getVal('p-doa');
  activeRecord.date = getVal('p-date');
  activeRecord.diagnosis = getVal('p-diagnosis');
  activeRecord.operation = getVal('p-operation');
  activeRecord.asa = getVal('p-asa');
  activeRecord.mallampati = getVal('p-mallampati');
  activeRecord.drughistory = getVal('p-drughistory');
  activeRecord.comorbiditiesOther = getVal('p-comorbidities-other');

  // Co-morbidities
  const selectedChips = [];
  document.querySelectorAll('#comorbidities-chips .chip-btn.selected').forEach(btn => {
    selectedChips.push(btn.getAttribute('data-val'));
  });
  activeRecord.comorbidities = selectedChips;

  saveRecords();
  renderRecordsUI();
}

function saveParticularsExplicit() {
  autoSaveParticulars();
  showToast("Particulars saved successfully");
}

function toggleChip(btn) {
  btn.classList.toggle('selected');
  updateCoMorbiditiesCount();
  autoSaveParticulars();
}

function updateCoMorbiditiesCount() {
  const count = document.querySelectorAll('#comorbidities-chips .chip-btn.selected').length;
  const countEl = document.getElementById('comorbidities-count');
  if (countEl) countEl.textContent = count;
}

function toggleCoMorbidities() {
  const body = document.getElementById('comorbidities-body');
  if (body) body.classList.toggle('hidden');
}

// --- TAB 3: INVESTIGATIONS AUTO-SAVE & SEROLOGY ---
function autoSaveInvestigations() {
  if (!activeRecord) return;
  if (!activeRecord.inv) activeRecord.inv = {};
  activeRecord.inv.hb = getVal('inv-hb');
  activeRecord.inv.wbc = getVal('inv-wbc');
  activeRecord.inv.platelet = getVal('inv-platelet');
  activeRecord.inv.pt = getVal('inv-pt');
  activeRecord.inv.aptt = getVal('inv-aptt');
  activeRecord.inv.inr = getVal('inv-inr');
  activeRecord.inv.sgpt = getVal('inv-sgpt');
  activeRecord.inv.sgot = getVal('inv-sgot');
  activeRecord.inv.alp = getVal('inv-alp');
  activeRecord.inv.bili = getVal('inv-bili');
  activeRecord.inv.albumin = getVal('inv-albumin');
  activeRecord.inv.creatinine = getVal('inv-creatinine');
  activeRecord.inv.bun = getVal('inv-bun');
  activeRecord.inv.na = getVal('inv-na');
  activeRecord.inv.k = getVal('inv-k');
  activeRecord.inv.rbs = getVal('inv-rbs');
  activeRecord.inv.hba1c = getVal('inv-hba1c');
  activeRecord.inv.tsh = getVal('inv-tsh');
  activeRecord.inv.ft4 = getVal('inv-ft4');
  activeRecord.inv.cxr = getVal('inv-cxr');
  activeRecord.inv.ecg = getVal('inv-ecg');
  activeRecord.inv.echo = getVal('inv-echo');

  saveRecords();
}

function saveInvestigationsExplicit() {
  autoSaveInvestigations();
  showToast("Investigations saved successfully");
}

function selectSerology(type, value) {
  if (!activeRecord) return;
  if (!activeRecord.inv) activeRecord.inv = {};
  activeRecord.inv[type] = value;
  updateSerologyChips(activeRecord.inv.hbsag, activeRecord.inv.hcv, activeRecord.inv.hiv);
  saveRecords();
}

function updateSerologyChips(hbsag = "Negative", hcv = "Negative", hiv = "Negative") {
  const map = {
    hbsag: { 'Negative': 'serology-hbsag-neg', 'Positive': 'serology-hbsag-pos', 'Not Done': 'serology-hbsag-nd' },
    hcv: { 'Negative': 'serology-hcv-neg', 'Positive': 'serology-hcv-pos', 'Not Done': 'serology-hcv-nd' },
    hiv: { 'Negative': 'serology-hiv-neg', 'Positive': 'serology-hiv-pos', 'Not Done': 'serology-hiv-nd' }
  };
  
  [ {type:'hbsag', val:hbsag}, {type:'hcv', val:hcv}, {type:'hiv', val:hiv} ].forEach(item => {
    const config = map[item.type];
    if (config) {
      Object.keys(config).forEach(k => {
        const el = document.getElementById(config[k]);
        if (el) {
          if (k.toLowerCase() === (item.val || "Negative").toLowerCase()) {
            el.classList.add('selected');
          } else {
            el.classList.remove('selected');
          }
        }
      });
    }
  });
}

// --- TAB 4: CALCULATORS & LIVE DOSING ---
function calculateBMIAndDoses() {
  const wt = activeRecord ? activeRecord.weight : 60;
  const ht = activeRecord ? activeRecord.height : 165;
  const sex = activeRecord ? activeRecord.sex : "Male";

  // BMI
  const htM = ht / 100;
  const bmi = (wt / (htM * htM)).toFixed(1);
  const bmiEl = document.getElementById('calc-bmi');
  if (bmiEl) bmiEl.textContent = bmi;

  // BSA (Mosteller formula)
  const bsa = Math.sqrt((ht * wt) / 3600).toFixed(2);
  const bsaEl = document.getElementById('calc-bsa');
  if (bsaEl) bsaEl.textContent = bsa;

  // IBW (Devine formula)
  const htInches = ht / 2.54;
  let ibw = 50;
  if (sex === "Female") {
    ibw = 45.5 + 2.3 * Math.max(0, htInches - 60);
  } else {
    ibw = 50.0 + 2.3 * Math.max(0, htInches - 60);
  }
  const ibwEl = document.getElementById('calc-ibw');
  if (ibwEl) ibwEl.textContent = ibw.toFixed(1);

  // LBW (Janmahasatian formula)
  let lbw = 0;
  if (sex === "Female") {
    lbw = (9270 * wt) / (8780 + (244 * (wt / (htM * htM))));
  } else {
    lbw = (9270 * wt) / (6680 + (216 * (wt / (htM * htM))));
  }
  const lbwEl = document.getElementById('calc-lbw');
  if (lbwEl) lbwEl.textContent = lbw.toFixed(1);

  // Adult Dosing Guide Live Table
  const dispWeightEl = document.getElementById('dosing-weight-disp');
  if (dispWeightEl) dispWeightEl.textContent = wt;

  renderAdultDosingTable(wt);
}

function renderAdultDosingTable(wt) {
  const tbody = document.getElementById('adult-dosing-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  DEFAULT_DRUG_CATALOG.forEach(d => {
    const minDose = (d.dosePerKgMin * wt).toFixed(d.unit === 'mg' ? 1 : 0);
    const maxDose = (d.dosePerKgMax * wt).toFixed(d.unit === 'mg' ? 1 : 0);
    
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>
        <strong style="color:var(--primary);">${d.name}</strong>
        <div style="font-size:0.72rem; color:var(--on-surface-variant);">${d.category} | ${d.route}</div>
      </td>
      <td style="font-size:0.8rem;">${d.dosePerKgMin} - ${d.dosePerKgMax} ${d.unit}/kg</td>
      <td>
        <strong style="color:var(--on-surface); font-size:0.92rem;">${minDose} - ${maxDose} ${d.unit}</strong>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// Fluid Holliday-Segar 4-2-1
function calcFluids() {
  const wt = activeRecord ? activeRecord.weight : 60;
  const npoHrs = parseFloat(getVal('calc-npo-hrs')) || 8;
  const traumaRate = parseFloat(getVal('calc-trauma-rate')) || 6;
  const dropFactor = parseInt(getVal('calc-drop-factor')) || 20;

  // Hourly maintenance: 4 mL/kg for 1st 10kg, 2 mL/kg for next 10kg, 1 mL/kg thereafter
  let maint = 0;
  if (wt <= 10) maint = wt * 4;
  else if (wt <= 20) maint = 40 + (wt - 10) * 2;
  else maint = 60 + (wt - 20) * 1;

  const totalNpoDeficit = maint * npoHrs;
  const surgicalTrauma = wt * traumaRate;

  const firstHr = (totalNpoDeficit * 0.5) + maint + surgicalTrauma;
  const nextHrs = (totalNpoDeficit * 0.25) + maint + surgicalTrauma;
  const dripRate = Math.round((firstHr * dropFactor) / 60);

  const maintEl = document.getElementById('calc-maint-rate');
  if (maintEl) maintEl.textContent = Math.round(maint);

  const defEl = document.getElementById('calc-npo-deficit');
  if (defEl) defEl.textContent = Math.round(totalNpoDeficit);

  const firstEl = document.getElementById('calc-first-hr');
  if (firstEl) firstEl.textContent = Math.round(firstHr);

  const nextEl = document.getElementById('calc-next-hrs');
  if (nextEl) nextEl.textContent = Math.round(nextHrs);

  const dripEl = document.getElementById('calc-drip-rate');
  if (dripEl) dripEl.textContent = dripRate;
}

// Syringe Pump Calculator
function handlePumpPresetChange() {
  const preset = getVal('pump-drug-preset');
  const volEl = document.getElementById('pump-vol');
  const massEl = document.getElementById('pump-mass');
  const doseEl = document.getElementById('pump-target-dose');

  if (preset === 'noradrenaline') {
    volEl.value = 50; massEl.value = 4; doseEl.value = 0.05;
  } else if (preset === 'dopamine') {
    volEl.value = 50; massEl.value = 200; doseEl.value = 5.0;
  } else if (preset === 'adrenaline') {
    volEl.value = 50; massEl.value = 4; doseEl.value = 0.05;
  } else if (preset === 'nitroglycerin') {
    volEl.value = 50; massEl.value = 50; doseEl.value = 0.5;
  } else if (preset === 'propofol') {
    volEl.value = 50; massEl.value = 500; doseEl.value = 50; // mcg/kg/min
  }
  calcPumpRate();
}

function calcPumpRate() {
  const wt = activeRecord ? activeRecord.weight : 60;
  const vol = parseFloat(getVal('pump-vol')) || 50;
  const massMg = parseFloat(getVal('pump-mass')) || 4;
  const targetMcg = parseFloat(getVal('pump-target-dose')) || 0.05;

  // Concentration in mcg/mL
  const totalMcg = massMg * 1000;
  const concMcgPerMl = totalMcg / vol;

  // Desired delivery: targetMcg * wt * 60 (mcg/hr)
  const mcgPerHour = targetMcg * wt * 60;
  const mlPerHour = (mcgPerHour / concMcgPerMl).toFixed(2);

  const resEl = document.getElementById('pump-calc-rate');
  if (resEl) resEl.textContent = mlPerHour;
}

// Maximum Allowable Blood Loss (MABL)
function calcMABL() {
  const wt = activeRecord ? activeRecord.weight : 60;
  const sex = activeRecord ? activeRecord.sex : "Male";
  const ebvMlPerKg = sex === "Female" ? 65 : 70;
  const ebv = wt * ebvMlPerKg;

  const hctInitial = parseFloat(getVal('mabl-hct-initial')) || 38;
  const hctTarget = parseFloat(getVal('mabl-hct-target')) || 26;

  let mabl = 0;
  if (hctInitial > hctTarget) {
    mabl = Math.round(ebv * ((hctInitial - hctTarget) / hctInitial));
  }
  const mablEl = document.getElementById('mabl-result');
  if (mablEl) mablEl.textContent = mabl;
}

// --- TAB 5: TECHNIQUE AUTO-SAVE ---
function handleTechniqueTypeChange() {
  const type = getVal('tech-type');
  const gaSec = document.getElementById('tech-ga-section');
  const regSec = document.getElementById('tech-reg-section');

  if (type === 'GA' || type === 'CSE') {
    if (gaSec) gaSec.style.display = 'block';
  } else {
    if (gaSec) gaSec.style.display = 'none';
  }

  if (type === 'SAB' || type === 'Epidural' || type === 'CSE' || type === 'PNB') {
    if (regSec) regSec.style.display = 'block';
  } else {
    if (regSec) regSec.style.display = 'none';
  }
}

function autoSaveTechnique() {
  if (!activeRecord) return;
  if (!activeRecord.tech) activeRecord.tech = {};

  activeRecord.tech.attending = getVal('tech-attending');
  activeRecord.tech.consultant = getVal('tech-consultant');
  activeRecord.tech.type = getVal('tech-type');
  activeRecord.tech.gaPremed = getVal('tech-ga-premed');
  activeRecord.tech.gaInduction = getVal('tech-ga-induction');
  activeRecord.tech.gaRelaxant = getVal('tech-ga-relaxant');
  activeRecord.tech.gaEtt = getVal('tech-ga-ett');
  activeRecord.tech.gaDepth = getVal('tech-ga-depth');
  activeRecord.tech.gaCl = getVal('tech-ga-cl');
  activeRecord.tech.gaCircuit = getVal('tech-ga-circuit');
  activeRecord.tech.gaVolatile = getVal('tech-ga-volatile');
  activeRecord.tech.timeAnesStart = getVal('tech-time-anes-start');
  activeRecord.tech.timeSurgStart = getVal('tech-time-surg-start');
  activeRecord.tech.timeSurgEnd = getVal('tech-time-surg-end');
  activeRecord.tech.timeExtubate = getVal('tech-time-extubate');
  activeRecord.tech.regSpace = getVal('tech-reg-space');
  activeRecord.tech.regNeedle = getVal('tech-reg-needle');
  activeRecord.tech.regDrug = getVal('tech-reg-drug');
  activeRecord.tech.regAdjuvant = getVal('tech-reg-adjuvant');
  activeRecord.tech.regLevel = getVal('tech-reg-level');
  activeRecord.tech.regBromage = getVal('tech-reg-bromage');

  saveRecords();
}

function saveTechniqueExplicit() {
  autoSaveTechnique();
  showToast("Technique saved successfully");
}

// --- TAB 6: VITALS LOGGING ---
function calcVitalsMAP() {
  const sbp = parseFloat(getVal('v-sbp'));
  const dbp = parseFloat(getVal('v-dbp'));
  const mapEl = document.getElementById('v-map');
  if (!isNaN(sbp) && !isNaN(dbp) && mapEl) {
    const map = Math.round((sbp + 2 * dbp) / 3);
    mapEl.value = map;
  }
}

function addVitalRemark(remark) {
  const el = document.getElementById('v-remarks');
  if (el) {
    el.value = el.value ? `${el.value}, ${remark}` : remark;
  }
}

function addVitalEntry() {
  if (!activeRecord) return;
  const time = getVal('v-time') || new Date().toTimeString().substring(0, 5);
  const sbp = getVal('v-sbp') || "120";
  const dbp = getVal('v-dbp') || "80";
  const map = getVal('v-map') || Math.round((parseInt(sbp) + 2 * parseInt(dbp)) / 3);
  const pulse = getVal('v-pulse') || "76";
  const spo2 = getVal('v-spo2') || "99";
  const etco2 = getVal('v-etco2') || "35";
  const remarks = getVal('v-remarks') || "--";

  const entry = {
    id: Date.now(),
    time,
    bp: `${sbp}/${dbp}`,
    map: map.toString(),
    pulse,
    spo2,
    etco2,
    remarks
  };

  if (!activeRecord.vitals) activeRecord.vitals = [];
  activeRecord.vitals.push(entry);
  saveRecords();
  renderVitalsTable();

  // Reset inputs
  document.getElementById('v-remarks').value = '';
  resetLogTimesToNow();
  showToast("Vitals entry logged");
}

function deleteVitalEntry(id) {
  if (!activeRecord || !activeRecord.vitals) return;
  activeRecord.vitals = activeRecord.vitals.filter(v => v.id !== id);
  saveRecords();
  renderVitalsTable();
  showToast("Vitals entry removed");
}

function renderVitalsTable() {
  const tbody = document.getElementById('vitals-table-body');
  const countEl = document.getElementById('vitals-count');
  if (!tbody || !activeRecord) return;

  const vitals = activeRecord.vitals || [];
  if (countEl) countEl.textContent = vitals.length;

  tbody.innerHTML = '';
  if (vitals.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:var(--on-surface-variant); padding:16px;">No vitals recorded yet.</td></tr>`;
    return;
  }

  // Reverse chronological
  [...vitals].reverse().forEach(v => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${v.time}</strong></td>
      <td>${v.bp} (${v.map})</td>
      <td>${v.pulse}</td>
      <td>${v.spo2}%</td>
      <td>${v.etco2 || '--'}</td>
      <td>${v.remarks}</td>
      <td><button class="btn-del" onclick="deleteVitalEntry(${v.id})">✕</button></td>
    `;
    tbody.appendChild(tr);
  });
}

// --- TAB 7: DRUG / GAS LOGGING ---
function autoSaveGases() {
  if (!activeRecord) return;
  if (!activeRecord.gases) activeRecord.gases = {};
  activeRecord.gases.o2 = getVal('gas-o2');
  activeRecord.gases.n2o = getVal('gas-n2o');
  activeRecord.gases.agent = getVal('gas-agent');
  saveRecords();
}

function selectQuickDrug(name, dose) {
  setVal('drug-name-input', name);
  setVal('drug-dose-input', dose);
}

function addDrugEntry() {
  if (!activeRecord) return;
  const name = getVal('drug-name-input');
  if (!name) {
    alert("Please enter a medication name.");
    return;
  }
  const dose = getVal('drug-dose-input') || "--";
  const time = getVal('drug-time-input') || new Date().toTimeString().substring(0, 5);

  const entry = {
    id: Date.now(),
    name,
    dose,
    time
  };

  if (!activeRecord.drugs) activeRecord.drugs = [];
  activeRecord.drugs.push(entry);
  saveRecords();
  renderDrugsTable();

  // Clear inputs
  setVal('drug-name-input', '');
  setVal('drug-dose-input', '');
  resetLogTimesToNow();
  showToast(`Logged ${name}`);
}

function deleteDrugEntry(id) {
  if (!activeRecord || !activeRecord.drugs) return;
  activeRecord.drugs = activeRecord.drugs.filter(d => d.id !== id);
  saveRecords();
  renderDrugsTable();
  showToast("Drug entry removed");
}

function renderDrugsTable() {
  const tbody = document.getElementById('drugs-table-body');
  const countEl = document.getElementById('drugs-count');
  if (!tbody || !activeRecord) return;

  const drugs = activeRecord.drugs || [];
  if (countEl) countEl.textContent = drugs.length;

  tbody.innerHTML = '';
  if (drugs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:var(--on-surface-variant); padding:16px;">No medications logged yet.</td></tr>`;
    return;
  }

  [...drugs].reverse().forEach(d => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${d.time}</strong></td>
      <td><strong>${d.name}</strong></td>
      <td>${d.dose}</td>
      <td><button class="btn-del" onclick="deleteDrugEntry(${d.id})">✕</button></td>
    `;
    tbody.appendChild(tr);
  });
}

// --- TAB 8: I&O FLUID BALANCE LOGGING ---
function setIOCrys(amount) {
  setVal('io-log-crys', amount);
}

function addIoEntry() {
  if (!activeRecord) return;
  const time = getVal('io-log-time') || new Date().toTimeString().substring(0, 5);
  const crys = parseFloat(getVal('io-log-crys')) || 0;
  const blood = parseFloat(getVal('io-log-blood')) || 0;
  const urine = parseFloat(getVal('io-log-urine')) || 0;
  const loss = parseFloat(getVal('io-log-loss')) || 0;
  const temp = getVal('io-log-temp') || "98.4";

  const entry = {
    id: Date.now(),
    time,
    crys,
    blood,
    totalIn: crys + blood,
    urine,
    loss,
    temp
  };

  if (!activeRecord.ioLogs) activeRecord.ioLogs = [];
  activeRecord.ioLogs.push(entry);
  saveRecords();
  renderIoTable();

  // Clear inputs
  setVal('io-log-crys', '');
  setVal('io-log-blood', '');
  setVal('io-log-urine', '');
  setVal('io-log-loss', '');
  resetLogTimesToNow();
  showToast("Fluid log recorded");
}

function deleteIoEntry(id) {
  if (!activeRecord || !activeRecord.ioLogs) return;
  activeRecord.ioLogs = activeRecord.ioLogs.filter(i => i.id !== id);
  saveRecords();
  renderIoTable();
  showToast("Fluid entry removed");
}

function renderIoTable() {
  const tbody = document.getElementById('io-table-body');
  const countEl = document.getElementById('io-logs-count');
  if (!tbody || !activeRecord) return;

  const logs = activeRecord.ioLogs || [];
  if (countEl) countEl.textContent = logs.length;

  let totalIn = 0;
  let totalLoss = 0;
  let totalUrine = 0;

  tbody.innerHTML = '';
  if (logs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--on-surface-variant); padding:16px;">No fluid logs recorded yet.</td></tr>`;
  } else {
    [...logs].reverse().forEach(l => {
      totalIn += l.totalIn;
      totalLoss += l.loss;
      totalUrine += l.urine;

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${l.time}</strong></td>
        <td>${l.totalIn} mL</td>
        <td style="color:var(--error);">${l.loss} mL</td>
        <td style="color:var(--warning);">${l.urine} mL</td>
        <td>${l.temp}°F</td>
        <td><button class="btn-del" onclick="deleteIoEntry(${l.id})">✕</button></td>
      `;
      tbody.appendChild(tr);
    });
  }

  // Update Summary Banner
  const inEl = document.getElementById('io-total-in');
  const lossEl = document.getElementById('io-total-loss');
  const urineEl = document.getElementById('io-total-urine');
  const netEl = document.getElementById('io-net-balance');

  const netBalance = totalIn - (totalLoss + totalUrine);
  if (inEl) inEl.textContent = totalIn;
  if (lossEl) lossEl.textContent = totalLoss;
  if (urineEl) urineEl.textContent = totalUrine;
  if (netEl) {
    netEl.textContent = `${netBalance >= 0 ? '+' : ''}${netBalance}`;
    netEl.style.color = netBalance >= 0 ? 'var(--success)' : 'var(--error)';
  }
}

// --- TAB 9: CLINICAL SUMMARY & RECORD SHEET ---
function autoSaveRecoveryNotes() {
  if (!activeRecord) return;
  activeRecord.recoveryNotes = getVal('sum-recovery-notes');
  saveRecords();
}

function renderSummarySheet() {
  if (!activeRecord) return;

  // Header & Particulars
  setTxt('sum-name', activeRecord.name);
  setTxt('sum-agesex', `${activeRecord.age}y / ${activeRecord.sex}`);
  setTxt('sum-weight', activeRecord.weight);
  setTxt('sum-bg', activeRecord.bg);
  setTxt('sum-reg', activeRecord.reg || '--');
  setTxt('sum-ward', activeRecord.ward || '--');
  setTxt('sum-date', activeRecord.date || '--');
  setTxt('sum-asa', activeRecord.asa);
  setTxt('sum-diagnosis', activeRecord.diagnosis || 'None specified');
  setTxt('sum-operation', activeRecord.operation || 'None specified');

  const comorbStr = (activeRecord.comorbidities && activeRecord.comorbidities.length > 0)
    ? activeRecord.comorbidities.join(', ') + (activeRecord.comorbiditiesOther ? `, ${activeRecord.comorbiditiesOther}` : '')
    : (activeRecord.comorbiditiesOther || 'None documented');
  setTxt('sum-comorbidities', comorbStr);

  // Investigations
  const inv = activeRecord.inv || {};
  setTxt('sum-hb', inv.hb || '--');
  setTxt('sum-plt', inv.platelet || '--');
  setTxt('sum-rbs', inv.rbs || '--');
  setTxt('sum-cr', inv.creatinine || '--');
  setTxt('sum-ptinr', `PT ${inv.pt || '--'}s, INR ${inv.inr || '--'}`);
  setTxt('sum-lytes', `Na+ ${inv.na || '--'} / K+ ${inv.k || '--'}`);
  setTxt('sum-cxr', inv.cxr || '--');
  setTxt('sum-ecg', inv.ecg || '--');

  // Technique
  const tech = activeRecord.tech || {};
  setTxt('sum-tech', tech.type || "GA");
  setTxt('sum-airway', tech.gaEtt || 'N/A');
  setTxt('sum-induction', `${tech.gaInduction || '--'}, ${tech.gaRelaxant || '--'}`);
  setTxt('sum-attending', tech.attending || doctorProfile.name);
  setTxt('sum-consultant', tech.consultant || 'Dr. Consultant');
  setTxt('sum-anes-time', `${tech.timeAnesStart || '--'} to ${tech.timeExtubate || '--'}`);
  setTxt('sum-surg-time', `${tech.timeSurgStart || '--'} to ${tech.timeSurgEnd || '--'}`);

  setTxt('sum-sig-attending', tech.attending || doctorProfile.name);
  setTxt('sum-sig-consultant', tech.consultant || 'Dr. Consultant');

  // Vitals Table
  const vBody = document.getElementById('sum-vitals-table');
  if (vBody) {
    vBody.innerHTML = '';
    (activeRecord.vitals || []).forEach(v => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${v.time}</td>
        <td>${v.bp} (${v.map})</td>
        <td>${v.pulse}</td>
        <td>${v.spo2}%</td>
        <td>${v.etco2 || '--'}</td>
        <td>${v.remarks}</td>
      `;
      vBody.appendChild(tr);
    });
    if ((activeRecord.vitals || []).length === 0) {
      vBody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--on-surface-variant);">No intra-op vitals recorded</td></tr>`;
    }
  }

  // Drugs Table
  const dBody = document.getElementById('sum-drugs-table');
  if (dBody) {
    dBody.innerHTML = '';
    (activeRecord.drugs || []).forEach(d => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${d.time}</td>
        <td><strong>${d.name}</strong></td>
        <td>${d.dose}</td>
      `;
      dBody.appendChild(tr);
    });
    if ((activeRecord.drugs || []).length === 0) {
      dBody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:var(--on-surface-variant);">No medications recorded</td></tr>`;
    }
  }

  // Fluid balance in summary
  let totalIn = 0, totalLoss = 0, totalUrine = 0;
  (activeRecord.ioLogs || []).forEach(l => {
    totalIn += l.totalIn;
    totalLoss += l.loss;
    totalUrine += l.urine;
  });
  setTxt('sum-io-in', totalIn);
  setTxt('sum-io-loss', totalLoss);
  setTxt('sum-io-urine', totalUrine);
  setTxt('sum-io-net', `${totalIn - (totalLoss + totalUrine)}`);

  // Recovery notes
  const notes = activeRecord.recoveryNotes || "Patient shifted to Post-Anesthesia Care Unit (PACU) with stable vitals. Supplemental oxygen via Hudson mask at 4 L/min. Continuous pulse oximetry monitoring.";
  setTxt('sum-recovery-display', notes);
}

function setTxt(id, txt) {
  const el = document.getElementById(id);
  if (el) el.textContent = (txt !== undefined && txt !== null && txt !== "") ? txt : "--";
}

function copyFormattedSummary() {
  if (!activeRecord) return;
  const text = `ANESTHESIA AID CLINICAL RECORD
Patient: ${activeRecord.name} (${activeRecord.age}y/${activeRecord.sex}, ${activeRecord.weight}kg)
Blood Grp: ${activeRecord.bg} | Reg: ${activeRecord.reg || '--'} | Date: ${activeRecord.date}
Diagnosis: ${activeRecord.diagnosis || '--'}
Proposed Surgery: ${activeRecord.operation || '--'}
ASA Status: ${activeRecord.asa} | Mallampati: ${activeRecord.mallampati}
Co-morbidities: ${activeRecord.comorbidities ? activeRecord.comorbidities.join(', ') : 'None'}
Technique: ${activeRecord.tech ? activeRecord.tech.type : 'GA'} | ETT: ${activeRecord.tech ? activeRecord.tech.gaEtt : '--'}
Attending: ${activeRecord.tech ? activeRecord.tech.attending : doctorProfile.name}
Total Infusion: ${document.getElementById('io-total-in')?.textContent || 0} mL | Blood Loss: ${document.getElementById('io-total-loss')?.textContent || 0} mL | Urine: ${document.getElementById('io-total-urine')?.textContent || 0} mL`;

  navigator.clipboard.writeText(text).then(() => {
    showToast("Summary copied to clipboard!");
  }).catch(() => {
    showToast("Copied to clipboard");
  });
}

// --- THEME & ACCENT MANAGEMENT ---
function setAppTheme(mode) {
  document.body.setAttribute('data-theme', mode);
  localStorage.setItem(STORAGE_KEY_THEME, mode);
  updateThemeButtons(mode);
}

function setAccentColor(accent) {
  document.body.setAttribute('data-accent', accent);
  localStorage.setItem(STORAGE_KEY_ACCENT, accent);
  showToast(`Accent set to ${accent}`);
}

function loadThemeAndAccent() {
  const savedTheme = localStorage.getItem(STORAGE_KEY_THEME) || 'light';
  const savedAccent = localStorage.getItem(STORAGE_KEY_ACCENT) || 'teal';
  document.body.setAttribute('data-theme', savedTheme);
  document.body.setAttribute('data-accent', savedAccent);
  updateThemeButtons(savedTheme);
}

function updateThemeButtons(mode) {
  const btnL = document.getElementById('theme-btn-light');
  const btnD = document.getElementById('theme-btn-dark');
  if (btnL && btnD) {
    if (mode === 'dark') {
      btnD.classList.add('btn-primary'); btnD.classList.remove('btn-outline');
      btnL.classList.remove('btn-primary'); btnL.classList.add('btn-outline');
    } else {
      btnL.classList.add('btn-primary'); btnL.classList.remove('btn-outline');
      btnD.classList.remove('btn-primary'); btnD.classList.add('btn-outline');
    }
  }
}

// --- SELECTIVE RESET (MATCHING ANDROID) ---
function executeSelectiveReset() {
  if (!activeRecord) return;
  const part = document.getElementById('reset-part').checked;
  const inv = document.getElementById('reset-inv').checked;
  const tech = document.getElementById('reset-tech').checked;
  const vit = document.getElementById('reset-vit').checked;
  const drug = document.getElementById('reset-drug').checked;
  const io = document.getElementById('reset-io').checked;

  if (part) {
    activeRecord.name = `Patient #${Math.floor(Math.random() * 900 + 100)}`;
    activeRecord.age = 35;
    activeRecord.weight = 60;
    activeRecord.height = 165;
    activeRecord.diagnosis = "";
    activeRecord.operation = "";
    activeRecord.drughistory = "";
    activeRecord.comorbidities = [];
    activeRecord.comorbiditiesOther = "";
  }
  if (inv) {
    activeRecord.inv = createNewPatientRecord().inv;
  }
  if (tech) {
    activeRecord.tech = createNewPatientRecord().tech;
  }
  if (vit) {
    activeRecord.vitals = [];
  }
  if (drug) {
    activeRecord.drugs = [];
  }
  if (io) {
    activeRecord.ioLogs = [];
  }

  saveRecords();
  populateActiveRecordToInputs();
  closeModal('modal-reset');
  showToast("Selective reset completed");
}

// --- DOCTOR PROFILE ---
function loadDoctorProfile() {
  const saved = localStorage.getItem(STORAGE_KEY_DOCTOR);
  if (saved) {
    try {
      doctorProfile = JSON.parse(saved);
    } catch (e) {}
  }
  setVal('doc-profile-name', doctorProfile.name);
  setVal('doc-profile-phone', doctorProfile.phone);
  setVal('doc-profile-bmdc', doctorProfile.bmdc);
  setVal('doc-profile-email', doctorProfile.email);
  setVal('doc-profile-inst', doctorProfile.institute);
}

function saveDoctorProfile() {
  doctorProfile.name = getVal('doc-profile-name') || "Dr. Clinician";
  doctorProfile.phone = getVal('doc-profile-phone');
  doctorProfile.bmdc = getVal('doc-profile-bmdc');
  doctorProfile.email = getVal('doc-profile-email');
  doctorProfile.institute = getVal('doc-profile-inst');

  localStorage.setItem(STORAGE_KEY_DOCTOR, JSON.stringify(doctorProfile));
  closeModal('modal-doctor');
  showToast("Doctor profile saved");
}

// --- DATA BACKUP & RESTORE (JSON) ---
function exportDataJSON() {
  const data = {
    app: "Anesthesia Aid",
    version: "2.0.0",
    exportDate: new Date().toISOString(),
    doctor: doctorProfile,
    records: recordsList
  };
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Anesthesia_Aid_Backup_${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast("Backup exported successfully");
}

function importDataJSON(replaceAll) {
  const fileInput = document.getElementById('import-json-file');
  if (!fileInput || !fileInput.files || fileInput.files.length === 0) {
    alert("Please select a valid .json backup file.");
    return;
  }
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      if (data.records && Array.isArray(data.records)) {
        if (replaceAll) {
          recordsList = data.records;
        } else {
          // Append unique records
          data.records.forEach(r => {
            if (!recordsList.some(existing => existing.id === r.id)) {
              recordsList.push(r);
            }
          });
        }
        if (data.doctor) doctorProfile = data.doctor;
        activeRecord = recordsList.length > 0 ? recordsList[0] : null;
        saveRecords();
        populateActiveRecordToInputs();
        closeModal('modal-backup');
        showToast("Records restored successfully!");
      } else {
        alert("Invalid backup file format.");
      }
    } catch (err) {
      alert("Error parsing backup JSON file: " + err.message);
    }
  };
  reader.readAsText(fileInput.files[0]);
}

// --- SUBSCRIPTION & BKASH ---
async function submitTrxID() {
  const trx = getVal('sub-trx-id').trim().toUpperCase();
  if (!trx) {
    alert("Please enter your bKash Transaction ID.");
    return;
  }

  const btn = document.getElementById('btn-submit-sub-trx');
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Submitting...";
  }

  if (currentAuthUser && currentAuthUser.email) {
    currentAuthUser.bKashTxnId = trx;
    currentAuthUser.account_status = isAdminEmail(currentAuthUser.email) ? 'APPROVED' : 'PENDING';
    currentAuthUser.account_type = 'subscribed';

    if (firestoreDb) {
      try {
        await firestoreDb.collection("users").doc(currentAuthUser.email.toLowerCase()).set({
          bKashTxnId: trx,
          account_status: currentAuthUser.account_status,
          account_type: 'subscribed'
        }, { merge: true });

        await firestoreDb.collection("notifications").add({
          title: "bKash Subscription Payment",
          message: `Dr. ${currentAuthUser.name} submitted bKash TxnID: ${trx}`,
          email: currentAuthUser.email,
          createdAt: new Date().toISOString(),
          read: false
        });
      } catch (e) {
        console.warn("Firestore subscription write notice:", e);
      }
    }
  }

  if (btn) {
    btn.disabled = false;
    btn.textContent = "Submit Transaction ID";
  }

  closeModal('modal-subscription');

  if (currentAuthUser && currentAuthUser.account_status === 'APPROVED') {
    setAppAuthState(AUTH_STATE_AUTHENTICATED, currentAuthUser);
    alert("Subscription activated! Unlimited access granted.");
  } else {
    setAppAuthState(AUTH_STATE_PENDING_APPROVAL, currentAuthUser);
    alert(`Thank you! Your bKash Transaction ID (${trx}) has been submitted for verification. We will verify and activate your account shortly.`);
  }
}

// --- CATALOG PIN SECURITY ---
function openCatalogPinModal() {
  openModal('modal-catalog-pin');
  setVal('catalog-pin-input', '');
}

function verifyCatalogPin() {
  const pin = getVal('catalog-pin-input');
  if (pin === "1234") {
    closeModal('modal-catalog-pin');
    alert("Formula editor unlocked! You may now adjust standard clinical doses.");
  } else {
    alert("Incorrect PIN. Default PIN is 1234.");
  }
}

// --- MODAL HELPERS ---
function openModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.add('active');
}

function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('active');
}

function closeModalOnOutside(event, id) {
  if (event.target && event.target.id === id) {
    closeModal(id);
  }
}

function openThemeModal() { openModal('modal-theme'); }
function openResetModal() { openModal('modal-reset'); }
function openPatientModal() { renderRecordsUI(); openModal('modal-patient'); }
function openDoctorProfileModal() { loadDoctorProfile(); openModal('modal-doctor'); }
function openBackupModal() { openModal('modal-backup'); }
function openSubscriptionModal() { openModal('modal-subscription'); }
function openAdminModal() {
  if (!currentAuthUser || !isAdminEmail(currentAuthUser.email)) {
    alert("Admin Dashboard is restricted to verified administrators.");
    return;
  }
  openModal('modal-admin');
  loadAdminUsers();
}

async function loadAdminUsers() {
  const container = document.getElementById('admin-user-list');
  if (!container) return;
  container.innerHTML = '<div style="padding:16px; text-align:center; color:var(--on-surface-variant);">Loading registered users...</div>';

  if (!firestoreDb) {
    container.innerHTML = '<div style="padding:16px; text-align:center; color:var(--on-surface-variant);">Firestore is offline. Connect to internet to manage users.</div>';
    return;
  }

  try {
    const snapshot = await firestoreDb.collection("users").get();
    if (snapshot.empty) {
      container.innerHTML = '<div style="padding:16px; text-align:center; color:var(--on-surface-variant);">No users found.</div>';
      return;
    }

    let html = '';
    snapshot.forEach(doc => {
      const u = doc.data();
      const statusBadge = u.account_status === 'APPROVED' 
        ? '<span style="background:var(--success); color:#fff; padding:2px 8px; border-radius:12px; font-size:0.75rem; font-weight:700;">APPROVED</span>'
        : (u.account_status === 'REJECTED'
          ? '<span style="background:var(--error); color:#fff; padding:2px 8px; border-radius:12px; font-size:0.75rem; font-weight:700;">REJECTED</span>'
          : '<span style="background:var(--warning); color:#fff; padding:2px 8px; border-radius:12px; font-size:0.75rem; font-weight:700;">PENDING</span>');

      html += `
        <div style="background:var(--surface-container); border-radius:8px; padding:12px; margin-bottom:10px; border:1px solid var(--outline-variant);">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
            <div style="font-weight:700; font-size:0.95rem;">${u.name || 'Dr. Unnamed'}</div>
            ${statusBadge}
          </div>
          <div style="font-size:0.8rem; color:var(--on-surface-variant); margin-bottom:4px;">
            📧 ${u.email || '--'} | 📞 ${u.phone || '--'}
          </div>
          <div style="font-size:0.8rem; color:var(--on-surface-variant); margin-bottom:4px;">
            🏥 ${u.institute || '--'} | BMDC: ${u.bmdc || '--'}
          </div>
          <div style="font-size:0.8rem; color:var(--on-surface-variant); margin-bottom:8px;">
            Type: <strong>${u.account_type || 'trial'}</strong> ${u.bKashTxnId ? `| TxnID: <strong style="color:var(--primary);">${u.bKashTxnId}</strong>` : ''}
          </div>
          <div style="display:flex; gap:8px;">
            <button class="btn btn-sm btn-primary" onclick="setAdminUserStatus('${u.email}', 'APPROVED')">✓ Approve</button>
            <button class="btn btn-sm btn-outline" style="color:var(--error); border-color:var(--error);" onclick="setAdminUserStatus('${u.email}', 'REJECTED')">✕ Reject</button>
          </div>
        </div>
      `;
    });
    container.innerHTML = html;
  } catch (err) {
    console.error("Error loading admin users:", err);
    container.innerHTML = `<div style="padding:16px; text-align:center; color:var(--error);">Failed to load users: ${err.message}</div>`;
  }
}

async function setAdminUserStatus(email, newStatus) {
  if (!email || !firestoreDb) return;
  try {
    await firestoreDb.collection("users").doc(email.toLowerCase()).update({
      account_status: newStatus,
      updated_at: new Date().toISOString()
    });
    showToast(`User status set to ${newStatus}`);
    loadAdminUsers();
  } catch (e) {
    alert("Failed to update status: " + e.message);
  }
}

// Speed dial toggle
function toggleSpeedDial() {
  const opts = document.getElementById('speed-dial-options');
  if (opts) opts.classList.toggle('open');
}
