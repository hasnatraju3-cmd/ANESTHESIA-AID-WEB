// ==========================================================================
// Anesthesia Aid - Core Progressive Web App Engine
// 1-to-1 Architecture & Logic Parity with Android Jetpack Compose App
// ==========================================================================

const STORAGE_KEY_RECORDS = 'anesthesia_records_list';
const STORAGE_KEY_ACTIVE_ID = 'anesthesia_active_record_id';
const STORAGE_KEY_DOCTOR = 'anesthesia_doctor_profile';
const STORAGE_KEY_THEME = 'anesthesia_theme_mode';
const STORAGE_KEY_ACCENT = 'anesthesia_accent_color';
const STORAGE_KEY_IOS_DISMISSED = 'anesthesia_ios_banner_dismissed';

let allRecords = [];
let activeRecord = null;
let currentTab = 'home';
let searchQuery = '';

// ==========================================================================
// Initialization & Startup
// ==========================================================================
document.addEventListener('DOMContentLoaded', () => {
  loadThemeSettings();
  loadDoctorProfile();
  loadAllRecords();
  initIosInstallBanner();
  updateTabIndicator('home');

  // Auto-fill time on entries
  const timeNow = getCurrentTimeHHMM();
  setValIfEmpty('vital-time', timeNow);
  setValIfEmpty('drug-time', timeNow);
  setValIfEmpty('io-entry-time', timeNow);

  // Pre-calculate calculators
  calculatePatientMetrics();
  calcFluids();
  calcPumpRate();
  calcMABL();
});

function getCurrentTimeHHMM() {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
}

function setValIfEmpty(id, val) {
  const el = document.getElementById(id);
  if (el && !el.value) {
    el.value = val;
  }
}

// ==========================================================================
// Navigation & Tab Switcher (Matching Android HorizontalPager)
// ==========================================================================
function switchTab(tabId) {
  currentTab = tabId;

  // Update Tab buttons
  document.querySelectorAll('.m3-tab-item').forEach(btn => {
    if (btn.dataset.tab === tabId) {
      btn.classList.add('active');
      btn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    } else {
      btn.classList.remove('active');
    }
  });

  // Update Panes
  document.querySelectorAll('.screen-pane').forEach(pane => {
    pane.classList.remove('active');
  });
  const targetPane = document.getElementById(`pane-${tabId}`);
  if (targetPane) {
    targetPane.classList.add('active');
  }

  updateTabIndicator(tabId);

  // If navigating to calculators, refresh calculation
  if (tabId === 'calculators') {
    syncPatientToCalculators();
  }

  // If navigating to record/summary, refresh clinical sheet
  if (tabId === 'record') {
    renderCaseSummary();
  }

  // Scroll to top of viewport
  const viewport = document.getElementById('viewport');
  if (viewport) viewport.scrollTop = 0;
}

function updateTabIndicator(tabId) {
  const activeBtn = document.querySelector(`.m3-tab-item[data-tab="${tabId}"]`);
  const indicator = document.getElementById('tab-indicator');
  if (activeBtn && indicator) {
    indicator.style.left = `${activeBtn.offsetLeft}px`;
    indicator.style.width = `${activeBtn.offsetWidth}px`;
  }
}

// ==========================================================================
// Records Management (Exact Parity with RecordsListScreen.kt)
// ==========================================================================
function loadAllRecords() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_RECORDS);
    allRecords = raw ? JSON.parse(raw) : [];
  } catch (e) {
    allRecords = [];
  }

  const activeId = localStorage.getItem(STORAGE_KEY_ACTIVE_ID);
  if (activeId && allRecords.length > 0) {
    activeRecord = allRecords.find(r => String(r.id) === String(activeId)) || allRecords[0];
  } else if (allRecords.length > 0) {
    activeRecord = allRecords[0];
  } else {
    // Initial starter record
    activeRecord = createNewRecordObject("Sample Patient");
    allRecords.push(activeRecord);
    saveAllRecords();
  }

  if (activeRecord) {
    localStorage.setItem(STORAGE_KEY_ACTIVE_ID, activeRecord.id);
  }

  renderRecordsList();
  populateActiveRecordToUI();
  updateHeaderPatientName();
}

function saveAllRecords() {
  localStorage.setItem(STORAGE_KEY_RECORDS, JSON.stringify(allRecords));
  if (activeRecord) {
    localStorage.setItem(STORAGE_KEY_ACTIVE_ID, activeRecord.id);
  }
  renderRecordsList();
  updateHeaderPatientName();
}

function createNewRecordObject(name = "") {
  const now = Date.now();
  const today = new Date().toISOString().split('T')[0];
  const docProfile = getSavedDoctorProfile();

  return {
    id: now,
    name: name || `Patient #${Math.floor(Math.random() * 9000 + 1000)}`,
    regNo: `REG-${Math.floor(Math.random() * 90000 + 10000)}`,
    age: 35,
    sex: "Male",
    bg: "O+",
    weight: 60,
    height: 165,
    ward: "OT-1",
    bed: "Bed-03",
    doa: today,
    doo: today,
    diagnosis: "Cholelithiasis",
    surgery: "Laparoscopic Cholecystectomy",
    asa: "ASA I",
    emergency: false,
    mallampati: "Class I",
    mouthOpening: "> 3 Fingers",
    tmd: "> 6.5 cm",
    neckMobility: "Full Range",
    teeth: "Normal",
    allergies: "None known",
    comorbidities: [],
    updatedAt: now,
    // Investigations
    inv: {
      hb: "12.5",
      platelet: "250000",
      wbc: "7500",
      esr: "12",
      pt: "12.0",
      inr: "1.0",
      aptt: "30.0",
      bt: "2.5",
      ct: "5.0",
      creatinine: "0.9",
      urea: "25",
      na: "138",
      k: "4.2",
      cl: "102",
      hco3: "24",
      sgpt: "32",
      sgot: "28",
      bili: "0.8",
      alkp: "90",
      alb: "4.2",
      rbs: "6.2",
      fbs: "5.4",
      hba1c: "5.6",
      tsh: "2.1",
      ecg: "Normal Sinus Rhythm",
      cxr: "Clear lung fields, normal cardiac size",
      echo: "Normal LV function, EF 62%",
      other: "",
      serology: { hbsag: "Negative", hcv: "Negative", hiv: "Negative", vdrl: "Non-reactive" },
      customLabs: []
    },
    // Technique & Team
    technique: {
      supervision: "individual", // individual or supervised
      attending: docProfile.name || "Dr. Abul Hasnat Khan",
      consultant: "",
      category: "ga", // ga or regional
      gaSubtype: "Combined",
      gaCircuit: "Circle System",
      gaRoute: "Endotracheal Tube",
      gaSize: "7.5",
      gaLength: "21 cm",
      gaTv: 450,
      gaIe: "1:2",
      gaRr: 12,
      gaPosition: "Supine",
      regType: "Spinal Anesthesia",
      regSite: "L3-L4",
      regTime: "09:00",
      regDepth: "",
      regPosition: "Sitting",
      regDrugs: [
        { name: "0.5% Bupivacaine Heavy", dose: "3.0", unit: "ml" },
        { name: "Fentanyl", dose: "25", unit: "mcg" }
      ]
    },
    // Gases
    gases: { o2: 2.0, n2o: 0.0, air: 2.0, agent: "Isoflurane", pct: 1.2 },
    // Vitals log
    vitals: [
      { time: "09:00", sys: 120, dia: 80, map: 93, pr: 74, spo2: 99, etco2: 35, event: "Induction" }
    ],
    // Drugs log
    drugs: [
      { time: "09:00", name: "Propofol", dose: "120 mg", route: "IV" },
      { time: "09:02", name: "Fentanyl", dose: "100 mcg", route: "IV" },
      { time: "09:03", name: "Atracurium", dose: "30 mg", route: "IV" }
    ],
    // I&O entries
    ioList: [
      { time: "09:00", infusion: "500 mL Hartmann's Solution", bloodLoss: 0, urine: 50, temp: 98.6 }
    ],
    // Comments & Attachments
    comments: "",
    attachments: []
  };
}

function renderRecordsList() {
  const container = document.getElementById('patient-list-container');
  const emptyState = document.getElementById('home-empty-state');
  const recordCountBadge = document.getElementById('record-count');
  const dropdownAllCount = document.getElementById('dropdown-all-records-label');
  const dropdownItems = document.getElementById('dropdown-patient-items');

  if (!container) return;

  const filtered = allRecords.filter(r => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (r.name && r.name.toLowerCase().includes(q)) ||
           (r.regNo && r.regNo.toLowerCase().includes(q)) ||
           (r.diagnosis && r.diagnosis.toLowerCase().includes(q)) ||
           (r.surgery && r.surgery.toLowerCase().includes(q));
  });

  if (recordCountBadge) recordCountBadge.textContent = allRecords.length;
  if (dropdownAllCount) dropdownAllCount.textContent = `View All Records (${allRecords.length})`;

  if (filtered.length === 0) {
    container.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
  } else {
    if (emptyState) emptyState.style.display = 'none';
    container.innerHTML = filtered.map(rec => {
      const isSelected = activeRecord && String(rec.id) === String(activeRecord.id);
      const dateStr = new Date(rec.updatedAt || rec.id).toLocaleDateString(undefined, {
        month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit'
      });
      const techType = rec.technique?.category === 'regional' ? (rec.technique?.regType || 'Regional Anesthesia') : (rec.technique?.gaSubtype || 'General Anesthesia');

      return `
        <div class="m3-patient-card ${isSelected ? 'active-record' : ''}" onclick="selectPatientRecord(${rec.id})">
          <div class="m3-card-avatar">👤</div>
          <div class="m3-card-info">
            <div class="m3-card-name-row">
              <span class="m3-card-name">${rec.name || 'Unnamed Patient'}</span>
              ${isSelected ? '<span class="m3-active-badge">ACTIVE</span>' : ''}
            </div>
            <div class="m3-card-meta">
              Reg: ${rec.regNo || 'N/A'} · Age: ${rec.age || '-'}Y · ${rec.sex || '-'} · ${rec.weight || '-'} kg · ${techType}
            </div>
            ${rec.surgery ? `<div class="m3-card-surgery">Surgery: ${rec.surgery}</div>` : ''}
            <div class="m3-card-date">Updated: ${dateStr}</div>
          </div>
          <button class="m3-delete-btn" onclick="event.stopPropagation(); deletePatientRecord(${rec.id});" title="Delete Patient Record">
            🗑️
          </button>
        </div>
      `;
    }).join('');
  }

  // Populate Dropdown Items
  if (dropdownItems) {
    dropdownItems.innerHTML = allRecords.map(rec => {
      const isSelected = activeRecord && String(rec.id) === String(activeRecord.id);
      return `
        <div class="m3-dropdown-item" onclick="selectPatientRecord(${rec.id}); togglePatientDropdown();" style="${isSelected ? 'font-weight:700; color:var(--primary);' : ''}">
          <span>👤</span>
          <span>${rec.name || 'Patient'} (${rec.regNo || rec.id})</span>
        </div>
      `;
    }).join('');
  }
}

function selectPatientRecord(id) {
  const found = allRecords.find(r => String(r.id) === String(id));
  if (found) {
    activeRecord = found;
    localStorage.setItem(STORAGE_KEY_ACTIVE_ID, activeRecord.id);
    renderRecordsList();
    populateActiveRecordToUI();
    updateHeaderPatientName();
    switchTab('particulars');
    showToast(`Switched to ${activeRecord.name}`);
  }
}

function openNewPatientModal() {
  const nameInput = document.getElementById('new-patient-name-input');
  if (nameInput) nameInput.value = '';
  openModal('modal-new-patient');
}

function executeCreateNewPatient() {
  const nameInput = document.getElementById('new-patient-name-input');
  const customName = nameInput ? nameInput.value.trim() : '';
  const newRec = createNewRecordObject(customName);
  allRecords.unshift(newRec);
  activeRecord = newRec;
  saveAllRecords();
  populateActiveRecordToUI();
  closeModal('modal-new-patient');
  switchTab('particulars');
  showToast("New patient record created");
}

function deletePatientRecord(id) {
  if (!confirm("Are you sure you want to delete this patient record?")) return;
  allRecords = allRecords.filter(r => String(r.id) !== String(id));
  if (activeRecord && String(activeRecord.id) === String(id)) {
    activeRecord = allRecords.length > 0 ? allRecords[0] : null;
  }
  saveAllRecords();
  if (activeRecord) {
    populateActiveRecordToUI();
  }
  showToast("Patient record deleted");
}

function updateHeaderPatientName() {
  const headerName = document.getElementById('header-patient-name');
  if (headerName) {
    headerName.textContent = activeRecord ? (activeRecord.name || `Patient #${activeRecord.id}`) : "Select Patient";
  }
}

function togglePatientDropdown(e) {
  if (e) e.stopPropagation();
  const menu = document.getElementById('patient-dropdown-menu');
  if (menu) menu.classList.toggle('active');
}

document.addEventListener('click', (e) => {
  const menu = document.getElementById('patient-dropdown-menu');
  const btn = document.getElementById('patient-selector-btn');
  if (menu && menu.classList.contains('active')) {
    if (!menu.contains(e.target) && !btn.contains(e.target)) {
      menu.classList.remove('active');
    }
  }
});

function handleRecordSearch(val) {
  searchQuery = val.trim();
  const badge = document.getElementById('active-filter-badge');
  const queryText = document.getElementById('filter-query-text');
  const countText = document.getElementById('filter-count-text');

  if (searchQuery) {
    if (badge) badge.style.display = 'flex';
    if (queryText) queryText.textContent = `Filter: "${searchQuery}"`;
  } else {
    if (badge) badge.style.display = 'none';
  }

  renderRecordsList();

  const filteredCount = allRecords.filter(r => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (r.name && r.name.toLowerCase().includes(q)) ||
           (r.regNo && r.regNo.toLowerCase().includes(q)) ||
           (r.diagnosis && r.diagnosis.toLowerCase().includes(q)) ||
           (r.surgery && r.surgery.toLowerCase().includes(q));
  }).length;
  if (countText) countText.textContent = `${filteredCount} found`;
}

function clearSearchFilter() {
  searchQuery = '';
  const input = document.getElementById('search-input');
  if (input) input.value = '';
  const badge = document.getElementById('active-filter-badge');
  if (badge) badge.style.display = 'none';
  renderRecordsList();
}

function executeFormReset() {
  if (!activeRecord) return;
  activeRecord.vitals = [];
  activeRecord.drugs = [];
  activeRecord.ioList = [];
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  populateActiveRecordToUI();
  closeModal('modal-reset');
  switchTab('home');
  showToast("Current form session cleared");
}

// ==========================================================================
// Sync Active Record to UI Form Inputs
// ==========================================================================
function populateActiveRecordToUI() {
  if (!activeRecord) return;

  // Demographics
  setVal('pt-name', activeRecord.name);
  setVal('pt-reg', activeRecord.regNo);
  setVal('pt-age', activeRecord.age);
  setVal('pt-sex', activeRecord.sex || 'Male');
  setVal('pt-bg', activeRecord.bg || 'O+');
  setVal('pt-weight', activeRecord.weight);
  setVal('pt-height', activeRecord.height);
  setVal('pt-ward', activeRecord.ward || '');
  setVal('pt-bed', activeRecord.bed || '');
  setVal('pt-doa', activeRecord.doa || '');
  setVal('pt-doo', activeRecord.doo || '');
  setVal('pt-diagnosis', activeRecord.diagnosis || '');
  setVal('pt-operation', activeRecord.surgery || '');
  setVal('pt-asa', activeRecord.asa || 'ASA I');
  const emgCheck = document.getElementById('pt-emergency');
  if (emgCheck) emgCheck.checked = !!activeRecord.emergency;

  // Airway & Physical Examination
  setVal('pt-mallampati', activeRecord.mallampati || 'Class I');
  setVal('pt-mouth', activeRecord.mouthOpening || '> 3 Fingers');
  setVal('pt-tmd', activeRecord.tmd || '> 6.5 cm');
  setVal('pt-neck', activeRecord.neckMobility || 'Full Range');
  setVal('pt-teeth', activeRecord.teeth || 'Normal');
  setVal('pt-allergies', activeRecord.allergies || 'None known');

  // Comorbidities chips
  const comChips = document.querySelectorAll('#comorbidities-chips .m3-chip');
  const activeCom = activeRecord.comorbidities || [];
  comChips.forEach(chip => {
    const code = chip.dataset.code || chip.textContent.trim();
    if (activeCom.includes(code)) {
      chip.classList.add('selected');
    } else {
      chip.classList.remove('selected');
    }
  });

  // Sync to calculators
  syncPatientToCalculators();

  // Investigations
  const inv = activeRecord.inv || {};
  setVal('inv-hb', inv.hb || '');
  setVal('inv-platelet', inv.platelet || '');
  setVal('inv-wbc', inv.wbc || '');
  setVal('inv-esr', inv.esr || '');
  setVal('inv-pt', inv.pt || '');
  setVal('inv-inr', inv.inr || '');
  setVal('inv-aptt', inv.aptt || '');
  setVal('inv-bt', inv.bt || '');
  setVal('inv-ct', inv.ct || '');
  setVal('inv-creatinine', inv.creatinine || '');
  setVal('inv-urea', inv.urea || '');
  setVal('inv-na', inv.na || '');
  setVal('inv-k', inv.k || '');
  setVal('inv-cl', inv.cl || '');
  setVal('inv-hco3', inv.hco3 || '');
  setVal('inv-sgpt', inv.sgpt || '');
  setVal('inv-sgot', inv.sgot || '');
  setVal('inv-bili', inv.bili || '');
  setVal('inv-alkp', inv.alkp || '');
  setVal('inv-alb', inv.alb || '');
  setVal('inv-rbs', inv.rbs || '');
  setVal('inv-fbs', inv.fbs || '');
  setVal('inv-hba1c', inv.hba1c || '');
  setVal('inv-tsh', inv.tsh || '');
  setVal('inv-ecg', inv.ecg || '');
  setVal('inv-cxr', inv.cxr || '');
  setVal('inv-echo', inv.echo || '');
  setVal('inv-other', inv.other || '');

  // Viral Serology
  const sero = inv.serology || {};
  renderSerologyChip('sero-hbsag', 'HBsAg', sero.hbsag || 'Negative');
  renderSerologyChip('sero-hcv', 'Anti-HCV', sero.hcv || 'Negative');
  renderSerologyChip('sero-hiv', 'HIV I & II', sero.hiv || 'Negative');
  renderSerologyChip('sero-vdrl', 'VDRL', sero.vdrl || 'Non-reactive');

  // Custom Labs
  renderCustomLabsList();

  // Technique & Team
  const tech = activeRecord.technique || {};
  setSupervisionMode(tech.supervision || 'individual', false);
  setVal('tech-attending', tech.attending || getSavedDoctorProfile().name || 'Dr. Abul Hasnat Khan');
  setVal('tech-consultant', tech.consultant || '');
  setTechniqueCategory(tech.category || 'ga', false);
  setVal('tech-ga-subtype', tech.gaSubtype || 'Combined');
  setVal('tech-ga-circuit', tech.gaCircuit || 'Circle System');
  setVal('tech-ga-route', tech.gaRoute || 'Endotracheal Tube');
  setVal('tech-ga-size', tech.gaSize || '7.5');
  setVal('tech-ga-length', tech.gaLength || '21 cm');
  setVal('tech-ga-tv', tech.gaTv || 450);
  setVal('tech-ga-ie', tech.gaIe || '1:2');
  setVal('tech-ga-rr', tech.gaRr || 12);
  setVal('tech-ga-position', tech.gaPosition || 'Supine');

  setVal('tech-reg-type', tech.regType || 'Spinal Anesthesia');
  setVal('tech-reg-site', tech.regSite || 'L3-L4');
  setVal('tech-reg-time', tech.regTime || '09:00');
  setVal('tech-reg-depth', tech.regDepth || '');
  setVal('tech-reg-position', tech.regPosition || 'Sitting');
  renderRegionalDrugs();

  // Gases
  const gas = activeRecord.gases || {};
  setVal('gas-o2', gas.o2 || 2.0);
  setVal('gas-n2o', gas.n2o || 0.0);
  setVal('gas-air', gas.air || 2.0);
  setVal('gas-agent', gas.agent || 'Isoflurane');
  setVal('gas-pct', gas.pct || 1.2);

  // Vitals & Drugs Tables
  renderVitalsTable();
  renderDrugsTable();

  // I&O Table & Cumulative Totals
  renderIoHistoryTable();
  calcIoCumulativeTotals();

  // Comments
  setVal('sum-comments-input', activeRecord.comments || '');

  // Attachments
  renderImageAttachments();
}

function setVal(id, val) {
  const el = document.getElementById(id);
  if (el && val !== undefined && val !== null) {
    el.value = val;
  }
}

function getVal(id) {
  const el = document.getElementById(id);
  return el ? el.value : '';
}

// ==========================================================================
// Auto-Saving Patient Demographics & Airway
// ==========================================================================
function autoSaveParticulars() {
  if (!activeRecord) return;
  activeRecord.name = getVal('pt-name');
  activeRecord.regNo = getVal('pt-reg');
  activeRecord.age = parseFloat(getVal('pt-age')) || 0;
  activeRecord.sex = getVal('pt-sex');
  activeRecord.bg = getVal('pt-bg');
  activeRecord.weight = parseFloat(getVal('pt-weight')) || 0;
  activeRecord.height = parseFloat(getVal('pt-height')) || 0;
  activeRecord.ward = getVal('pt-ward');
  activeRecord.bed = getVal('pt-bed');
  activeRecord.doa = getVal('pt-doa');
  activeRecord.doo = getVal('pt-doo');
  activeRecord.diagnosis = getVal('pt-diagnosis');
  activeRecord.surgery = getVal('pt-operation');
  activeRecord.asa = getVal('pt-asa');
  const emg = document.getElementById('pt-emergency');
  activeRecord.emergency = emg ? emg.checked : false;

  activeRecord.mallampati = getVal('pt-mallampati');
  activeRecord.mouthOpening = getVal('pt-mouth');
  activeRecord.tmd = getVal('pt-tmd');
  activeRecord.neckMobility = getVal('pt-neck');
  activeRecord.teeth = getVal('pt-teeth');
  activeRecord.allergies = getVal('pt-allergies');

  // Co-morbidities chips
  const selectedChips = [];
  document.querySelectorAll('#comorbidities-chips .m3-chip.selected').forEach(chip => {
    selectedChips.push(chip.dataset.code || chip.textContent.trim());
  });
  activeRecord.comorbidities = selectedChips;

  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  syncPatientToCalculators();
}

function toggleChip(chipEl, code) {
  chipEl.classList.toggle('selected');
  autoSaveParticulars();
}

// ==========================================================================
// Investigations Tab (Matching InvestigationsScreen.kt)
// ==========================================================================
function autoSaveInvestigations() {
  if (!activeRecord) return;
  if (!activeRecord.inv) activeRecord.inv = {};
  const inv = activeRecord.inv;

  inv.hb = getVal('inv-hb');
  inv.platelet = getVal('inv-platelet');
  inv.wbc = getVal('inv-wbc');
  inv.esr = getVal('inv-esr');
  inv.pt = getVal('inv-pt');
  inv.inr = getVal('inv-inr');
  inv.aptt = getVal('inv-aptt');
  inv.bt = getVal('inv-bt');
  inv.ct = getVal('inv-ct');
  inv.creatinine = getVal('inv-creatinine');
  inv.urea = getVal('inv-urea');
  inv.na = getVal('inv-na');
  inv.k = getVal('inv-k');
  inv.cl = getVal('inv-cl');
  inv.hco3 = getVal('inv-hco3');
  inv.sgpt = getVal('inv-sgpt');
  inv.sgot = getVal('inv-sgot');
  inv.bili = getVal('inv-bili');
  inv.alkp = getVal('inv-alkp');
  inv.alb = getVal('inv-alb');
  inv.rbs = getVal('inv-rbs');
  inv.fbs = getVal('inv-fbs');
  inv.hba1c = getVal('inv-hba1c');
  inv.tsh = getVal('inv-tsh');
  inv.ecg = getVal('inv-ecg');
  inv.cxr = getVal('inv-cxr');
  inv.echo = getVal('inv-echo');
  inv.other = getVal('inv-other');

  activeRecord.updatedAt = Date.now();
  saveAllRecords();
}

function toggleSerology(id, testName) {
  if (!activeRecord) return;
  if (!activeRecord.inv) activeRecord.inv = {};
  if (!activeRecord.inv.serology) activeRecord.inv.serology = {};

  const keyMap = {
    'sero-hbsag': 'hbsag',
    'sero-hcv': 'hcv',
    'sero-hiv': 'hiv',
    'sero-vdrl': 'vdrl'
  };
  const key = keyMap[id];
  const current = activeRecord.inv.serology[key] || 'Negative';

  let nextVal = '';
  if (testName === 'VDRL') {
    nextVal = (current === 'Non-reactive') ? 'Reactive' : 'Non-reactive';
  } else {
    nextVal = (current === 'Negative') ? 'Positive' : 'Negative';
  }

  activeRecord.inv.serology[key] = nextVal;
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderSerologyChip(id, testName, nextVal);
}

function renderSerologyChip(id, testName, val) {
  const el = document.getElementById(id);
  if (!el) return;
  const isPositive = val === 'Positive' || val === 'Reactive';
  el.textContent = `${testName}: ${val}`;
  if (isPositive) {
    el.style.backgroundColor = 'var(--error-container)';
    el.style.color = 'var(--error)';
    el.style.borderColor = 'var(--error)';
    el.style.fontWeight = '700';
  } else {
    el.style.backgroundColor = '';
    el.style.color = '';
    el.style.borderColor = '';
    el.style.fontWeight = '500';
  }
}

// Custom Lab Tests
function openCustomLabModal() {
  setVal('custom-lab-name', '');
  setVal('custom-lab-value', '');
  setVal('custom-lab-unit', '');
  openModal('modal-custom-lab');
}

function addCustomLabInvestigation() {
  if (!activeRecord) return;
  const name = getVal('custom-lab-name').trim();
  const value = getVal('custom-lab-value').trim();
  const unit = getVal('custom-lab-unit').trim();

  if (!name || !value) {
    alert("Please enter test name and result value.");
    return;
  }

  if (!activeRecord.inv) activeRecord.inv = {};
  if (!activeRecord.inv.customLabs) activeRecord.inv.customLabs = [];

  activeRecord.inv.customLabs.push({ name, value, unit });
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderCustomLabsList();
  closeModal('modal-custom-lab');
  showToast(`Added ${name}`);
}

function deleteCustomLab(idx) {
  if (!activeRecord || !activeRecord.inv?.customLabs) return;
  activeRecord.inv.customLabs.splice(idx, 1);
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderCustomLabsList();
}

function renderCustomLabsList() {
  const container = document.getElementById('inv-custom-container');
  if (!container || !activeRecord) return;

  const labs = activeRecord.inv?.customLabs || [];
  if (labs.length === 0) {
    container.innerHTML = '';
    return;
  }

  container.innerHTML = `
    <div style="margin-top:12px; border-top:1px dashed var(--outline-variant); padding-top:8px;">
      <span style="font-size:12px; font-weight:700; color:var(--primary);">Custom Investigations</span>
      <div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:6px;">
        ${labs.map((l, i) => `
          <span class="m3-chip selected" style="display:inline-flex; align-items:center; gap:6px;">
            <strong>${l.name}:</strong> ${l.value} ${l.unit || ''}
            <span onclick="event.stopPropagation(); deleteCustomLab(${i});" style="cursor:pointer; color:var(--error); font-weight:bold; margin-left:4px;">✕</span>
          </span>
        `).join('')}
      </div>
    </div>
  `;
}

// ==========================================================================
// Clinical Calculators (Exact Parity with DoseCalculatorScreen.kt)
// ==========================================================================
function toggleCalcCard(headerEl) {
  const card = headerEl.closest('.m3-expandable-card');
  if (card) {
    card.classList.toggle('expanded');
  }
}

function syncPatientToCalculators() {
  if (!activeRecord) return;
  setVal('calc-wt', activeRecord.weight || 60);
  setVal('calc-ht', activeRecord.height || 165);
  setVal('calc-sex', activeRecord.sex || 'Male');
  calculatePatientMetrics();
  calcFluids();
  calcPumpRate();
  calcMABL();
}

function calculatePatientMetrics() {
  const wt = parseFloat(getVal('calc-wt')) || (activeRecord?.weight || 60);
  const ht = parseFloat(getVal('calc-ht')) || (activeRecord?.height || 165);
  const sex = getVal('calc-sex') || (activeRecord?.sex || 'Male');

  const htM = ht / 100;
  const htInches = ht / 2.54;
  const inchesOver5Ft = Math.max(0, htInches - 60);

  // BMI
  const bmi = (wt / (htM * htM)).toFixed(1);

  // BSA (Mosteller Formula: sqrt((ht * wt) / 3600))
  const bsa = Math.sqrt((ht * wt) / 3600).toFixed(2);

  // Ideal Body Weight (IBW - Devine Formula)
  let ibw = 50.0;
  if (sex === 'Female') {
    ibw = 45.5 + 2.3 * inchesOver5Ft;
  } else {
    ibw = 50.0 + 2.3 * inchesOver5Ft;
  }
  ibw = Math.max(10, Math.round(ibw * 10) / 10);

  // Lean Body Weight (LBW - Janmahasatian formula)
  let lbw = 0;
  const bmiNum = parseFloat(bmi);
  if (sex === 'Female') {
    lbw = (9270 * wt) / (8780 + 244 * bmiNum);
  } else {
    lbw = (9270 * wt) / (6680 + 216 * bmiNum);
  }
  lbw = Math.round(lbw * 10) / 10;

  // Display metrics
  setElemText('calc-bmi-val', isNaN(bmi) ? '--' : bmi);
  setElemText('calc-bsa-val', isNaN(bsa) ? '-- m²' : `${bsa} m²`);
  setElemText('calc-ibw-val', isNaN(ibw) ? '-- kg' : `${ibw} kg`);
  setElemText('calc-lbw-val', isNaN(lbw) ? '-- kg' : `${lbw} kg`);

  // BMI classification
  const bmiBadge = document.getElementById('calc-bmi-badge');
  if (bmiBadge && !isNaN(bmi)) {
    if (bmi < 18.5) {
      bmiBadge.textContent = 'Underweight';
      bmiBadge.style.background = '#FED7AA';
      bmiBadge.style.color = '#9A3412';
    } else if (bmi <= 24.9) {
      bmiBadge.textContent = 'Normal';
      bmiBadge.style.background = 'var(--primary-container)';
      bmiBadge.style.color = 'var(--primary)';
    } else if (bmi <= 29.9) {
      bmiBadge.textContent = 'Overweight';
      bmiBadge.style.background = '#FEF08A';
      bmiBadge.style.color = '#854D0E';
    } else {
      bmiBadge.textContent = 'Obese';
      bmiBadge.style.background = 'var(--error-container)';
      bmiBadge.style.color = 'var(--error)';
    }
  }

  // Populate dynamic drug doses
  renderDoseCalculatorTable(wt, ibw);
}

function renderDoseCalculatorTable(wt, ibw) {
  const tbody = document.getElementById('calculated-dose-tbody');
  if (!tbody) return;

  const drugs = [
    { name: "Propofol (Induction)", std: "1.5 - 2.5 mg/kg", dose: `${(wt * 1.5).toFixed(0)} - ${(wt * 2.5).toFixed(0)} mg`, route: "IV Bolus" },
    { name: "Etomidate", std: "0.2 - 0.3 mg/kg", dose: `${(wt * 0.2).toFixed(1)} - ${(wt * 0.3).toFixed(1)} mg`, route: "IV Bolus" },
    { name: "Ketamine", std: "1.0 - 2.0 mg/kg", dose: `${(wt * 1.0).toFixed(0)} - ${(wt * 2.0).toFixed(0)} mg`, route: "IV Bolus" },
    { name: "Thiopental Sodium", std: "3.0 - 5.0 mg/kg", dose: `${(wt * 3.0).toFixed(0)} - ${(wt * 5.0).toFixed(0)} mg`, route: "IV Bolus" },
    { name: "Suxamethonium (Actual Wt)", std: "1.0 - 1.5 mg/kg", dose: `${(wt * 1.0).toFixed(0)} - ${(wt * 1.5).toFixed(0)} mg`, route: "IV Bolus" },
    { name: "Rocuronium (IBW)", std: "0.6 - 1.2 mg/kg", dose: `${(ibw * 0.6).toFixed(0)} - ${(ibw * 1.2).toFixed(0)} mg`, route: "IV Bolus" },
    { name: "Atracurium (IBW)", std: "0.4 - 0.5 mg/kg", dose: `${(ibw * 0.4).toFixed(0)} - ${(ibw * 0.5).toFixed(0)} mg`, route: "IV Bolus" },
    { name: "Vecuronium (IBW)", std: "0.08 - 0.1 mg/kg", dose: `${(ibw * 0.08).toFixed(1)} - ${(ibw * 0.1).toFixed(1)} mg`, route: "IV Bolus" },
    { name: "Fentanyl (Analgesia)", std: "1.0 - 2.0 mcg/kg", dose: `${(wt * 1.0).toFixed(0)} - ${(wt * 2.0).toFixed(0)} mcg`, route: "IV Bolus" },
    { name: "Morphine", std: "0.1 - 0.15 mg/kg", dose: `${(wt * 0.1).toFixed(1)} - ${(wt * 0.15).toFixed(1)} mg`, route: "IV Slow" },
    { name: "Neostigmine Reversal", std: "0.04 - 0.05 mg/kg", dose: `${(wt * 0.04).toFixed(2)} - ${(wt * 0.05).toFixed(2)} mg`, route: "IV (with Glyco)" },
    { name: "Glycopyrrolate Reversal", std: "0.01 mg/kg", dose: `${(wt * 0.01).toFixed(2)} mg`, route: "IV Bolus" },
    { name: "Atropine Sulfate", std: "0.01 - 0.02 mg/kg", dose: `${(wt * 0.01).toFixed(2)} - ${(wt * 0.02).toFixed(2)} mg`, route: "IV Bolus" },
    { name: "Ondansetron", std: "0.1 mg/kg (Max 4mg)", dose: `${Math.min(4, wt * 0.1).toFixed(1)} mg`, route: "IV Bolus" }
  ];

  tbody.innerHTML = drugs.map(d => `
    <tr>
      <td><strong>${d.name}</strong></td>
      <td>${d.std}</td>
      <td><strong style="color:var(--primary); font-size:13px;">${d.dose}</strong></td>
      <td>${d.route}</td>
    </tr>
  `).join('');
}

function setElemText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

// 4-2-1 Fasting & Fluid Deficit Calculator
function calcFluids() {
  const wt = parseFloat(getVal('calc-wt')) || (activeRecord?.weight || 60);
  const fasting = parseFloat(getVal('calc-fasting')) || 8;

  // Holliday-Segar 4-2-1
  let hourly = 0;
  if (wt <= 10) hourly = wt * 4;
  else if (wt <= 20) hourly = 40 + (wt - 10) * 2;
  else hourly = 60 + (wt - 20) * 1;

  const deficit = hourly * fasting;
  const h1 = (deficit * 0.5) + hourly;
  const h2 = (deficit * 0.25) + hourly;
  const h3 = (deficit * 0.25) + hourly;

  setElemText('calc-maint-rate', `${Math.round(hourly)} mL/hr`);
  setElemText('calc-deficit', `${Math.round(deficit)} mL`);
  setElemText('calc-fluid-h1', `${Math.round(h1)} mL`);
  setElemText('calc-fluid-h2', `${Math.round(h2)} mL`);
  setElemText('calc-fluid-h3', `${Math.round(h3)} mL`);
}

// Infusion Syringe Pump Calculator
function handlePumpPresetChange() {
  const drug = getVal('calc-pump-drug');
  const concInput = document.getElementById('calc-pump-conc');
  const doseInput = document.getElementById('calc-pump-dose');

  if (drug === 'norepi') {
    if (concInput) concInput.value = 0.08; // 4mg in 50ml
    if (doseInput) doseInput.value = 0.05; // mcg/kg/min
  } else if (drug === 'epi') {
    if (concInput) concInput.value = 0.08; // 4mg in 50ml
    if (doseInput) doseInput.value = 0.05;
  } else if (drug === 'dopa') {
    if (concInput) concInput.value = 4.0;  // 200mg in 50ml
    if (doseInput) doseInput.value = 5.0;  // mcg/kg/min
  } else if (drug === 'dobut') {
    if (concInput) concInput.value = 5.0;  // 250mg in 50ml
    if (doseInput) doseInput.value = 5.0;
  } else if (drug === 'propofol') {
    if (concInput) concInput.value = 10.0; // 10mg/ml
    if (doseInput) doseInput.value = 6.0;  // mg/kg/hr
  } else if (drug === 'dexmed') {
    if (concInput) concInput.value = 0.004; // 200mcg in 50ml
    if (doseInput) doseInput.value = 0.4;  // mcg/kg/hr
  } else if (drug === 'fent') {
    if (concInput) concInput.value = 0.01; // 500mcg in 50ml
    if (doseInput) doseInput.value = 1.0;  // mcg/kg/hr
  }
  calcPumpRate();
}

function calcPumpRate() {
  const wt = parseFloat(getVal('calc-wt')) || (activeRecord?.weight || 60);
  const drug = getVal('calc-pump-drug');
  const conc = parseFloat(getVal('calc-pump-conc')) || 0.08; // mg/mL
  const dose = parseFloat(getVal('calc-pump-dose')) || 0.05;

  let rate = 0;
  if (drug === 'propofol') {
    // dose in mg/kg/hr -> Rate (mL/hr) = (dose * wt) / conc
    rate = (dose * wt) / conc;
  } else if (drug === 'dexmed' || drug === 'fent') {
    // dose in mcg/kg/hr -> Rate (mL/hr) = (dose * wt) / (conc * 1000)
    rate = (dose * wt) / (conc * 1000);
  } else {
    // dose in mcg/kg/min -> Rate (mL/hr) = (dose * wt * 60) / (conc * 1000)
    rate = (dose * wt * 60) / (conc * 1000);
  }

  const resEl = document.getElementById('calc-pump-result');
  if (resEl) {
    resEl.textContent = isNaN(rate) ? '--' : `${rate.toFixed(1)} mL/hr`;
  }
}

// Maximum Allowable Blood Loss (MABL)
function calcMABL() {
  const wt = parseFloat(getVal('calc-wt')) || (activeRecord?.weight || 60);
  const startHct = parseFloat(getVal('calc-mabl-start')) || 38;
  const minHct = parseFloat(getVal('calc-mabl-min')) || 28;
  const ebvCoeff = parseFloat(getVal('calc-mabl-ebv-coeff')) || 70;

  const ebv = wt * ebvCoeff;
  const avgHct = (startHct + minHct) / 2;
  const mabl = (ebv * (startHct - minHct)) / avgHct;

  setElemText('calc-ebv-result', `${Math.round(ebv).toLocaleString()} mL`);
  setElemText('calc-mabl-result', `${Math.max(0, Math.round(mabl)).toLocaleString()} mL`);
}

// ==========================================================================
// Technique & Team (Matching TechniqueFluidsScreen.kt)
// ==========================================================================
function setSupervisionMode(mode, save = true) {
  const indBtn = document.getElementById('supervision-individual');
  const supBtn = document.getElementById('supervision-supervised');
  const consultantBox = document.getElementById('tech-consultant-box');

  if (mode === 'supervised') {
    if (indBtn) indBtn.classList.remove('active');
    if (supBtn) supBtn.classList.add('active');
    if (consultantBox) consultantBox.style.display = 'block';
  } else {
    if (indBtn) indBtn.classList.add('active');
    if (supBtn) supBtn.classList.remove('active');
    if (consultantBox) consultantBox.style.display = 'none';
  }

  if (activeRecord) {
    if (!activeRecord.technique) activeRecord.technique = {};
    activeRecord.technique.supervision = mode;
    if (save) {
      activeRecord.updatedAt = Date.now();
      saveAllRecords();
    }
  }
}

function setTechniqueCategory(cat, save = true) {
  const gaBtn = document.getElementById('tech-mode-ga');
  const regBtn = document.getElementById('tech-mode-regional');
  const gaSec = document.getElementById('tech-ga-section');
  const regSec = document.getElementById('tech-regional-section');

  if (cat === 'regional') {
    if (gaBtn) gaBtn.classList.remove('active');
    if (regBtn) regBtn.classList.add('active');
    if (gaSec) gaSec.style.display = 'none';
    if (regSec) regSec.style.display = 'block';
  } else {
    if (gaBtn) gaBtn.classList.add('active');
    if (regBtn) regBtn.classList.remove('active');
    if (gaSec) gaSec.style.display = 'block';
    if (regSec) regSec.style.display = 'none';
  }

  if (activeRecord) {
    if (!activeRecord.technique) activeRecord.technique = {};
    activeRecord.technique.category = cat;
    if (save) {
      activeRecord.updatedAt = Date.now();
      saveAllRecords();
    }
  }
}

function autoSaveTechnique() {
  if (!activeRecord) return;
  if (!activeRecord.technique) activeRecord.technique = {};
  const t = activeRecord.technique;

  t.attending = getVal('tech-attending');
  t.consultant = getVal('tech-consultant');
  t.gaSubtype = getVal('tech-ga-subtype');
  t.gaCircuit = getVal('tech-ga-circuit');
  t.gaRoute = getVal('tech-ga-route');
  t.gaSize = getVal('tech-ga-size');
  t.gaLength = getVal('tech-ga-length');
  t.gaTv = parseFloat(getVal('tech-ga-tv')) || 0;
  t.gaIe = getVal('tech-ga-ie');
  t.gaRr = parseFloat(getVal('tech-ga-rr')) || 0;
  t.gaPosition = getVal('tech-ga-position');

  t.regType = getVal('tech-reg-type');
  t.regSite = getVal('tech-reg-site');
  t.regTime = getVal('tech-reg-time');
  t.regDepth = getVal('tech-reg-depth');
  t.regPosition = getVal('tech-reg-position');

  activeRecord.updatedAt = Date.now();
  saveAllRecords();
}

function saveDoctorsTeam() {
  autoSaveTechnique();
  showToast("Doctor profiles updated");
}

function saveTechniqueExplicit() {
  autoSaveTechnique();
  showToast("Technique parameters saved");
}

// Regional Drugs Dynamic List
function addRegionalDrugRow() {
  if (!activeRecord) return;
  if (!activeRecord.technique) activeRecord.technique = {};
  if (!activeRecord.technique.regDrugs) activeRecord.technique.regDrugs = [];

  activeRecord.technique.regDrugs.push({ name: "Drug Name", dose: "1.0", unit: "ml" });
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderRegionalDrugs();
}

function deleteRegionalDrugRow(idx) {
  if (!activeRecord || !activeRecord.technique?.regDrugs) return;
  activeRecord.technique.regDrugs.splice(idx, 1);
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderRegionalDrugs();
}

function updateRegionalDrug(idx, field, val) {
  if (!activeRecord || !activeRecord.technique?.regDrugs) return;
  if (activeRecord.technique.regDrugs[idx]) {
    activeRecord.technique.regDrugs[idx][field] = val;
    activeRecord.updatedAt = Date.now();
    saveAllRecords();
  }
}

function renderRegionalDrugs() {
  const container = document.getElementById('tech-regional-drugs-container');
  if (!container || !activeRecord) return;

  const list = activeRecord.technique?.regDrugs || [];
  if (list.length === 0) {
    container.innerHTML = `<div style="font-size:12px; color:var(--on-surface-variant); padding:4px 0;">No regional drugs added yet. Click "+ Add Drug" above.</div>`;
    return;
  }

  container.innerHTML = list.map((d, i) => `
    <div class="m3-row" style="margin-bottom:6px; align-items:center;">
      <div class="m3-col" style="flex:2;">
        <input type="text" class="m3-field-input" value="${d.name}" placeholder="Drug" oninput="updateRegionalDrug(${i}, 'name', this.value)">
      </div>
      <div class="m3-col" style="flex:1;">
        <input type="text" class="m3-field-input" value="${d.dose}" placeholder="Dose" oninput="updateRegionalDrug(${i}, 'dose', this.value)">
      </div>
      <div class="m3-col" style="flex:1;">
        <input type="text" class="m3-field-input" value="${d.unit}" placeholder="Unit (ml/mg)" oninput="updateRegionalDrug(${i}, 'unit', this.value)">
      </div>
      <div>
        <button class="m3-icon-btn" style="color:var(--error); width:32px; height:32px;" onclick="deleteRegionalDrugRow(${i})">✕</button>
      </div>
    </div>
  `).join('');
}

// Gases & Vaporizer
function autoSaveGases() {
  if (!activeRecord) return;
  activeRecord.gases = {
    o2: parseFloat(getVal('gas-o2')) || 0,
    n2o: parseFloat(getVal('gas-n2o')) || 0,
    air: parseFloat(getVal('gas-air')) || 0,
    agent: getVal('gas-agent'),
    pct: parseFloat(getVal('gas-pct')) || 0
  };
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
}

// ==========================================================================
// Intra-Op Vitals (Matching IntraOpScreen.kt)
// ==========================================================================
function calcVitalsMAP() {
  const sys = parseFloat(getVal('vital-sys')) || 0;
  const dia = parseFloat(getVal('vital-dia')) || 0;
  if (sys > 0 && dia > 0) {
    const map = Math.round(dia + (sys - dia) / 3);
    const mapInput = document.getElementById('vital-map');
    if (mapInput) mapInput.value = `${map} mmHg`;
  }
}

function addVitalEntry() {
  if (!activeRecord) return;
  const time = getVal('vital-time') || getCurrentTimeHHMM();
  const sys = parseInt(getVal('vital-sys')) || 120;
  const dia = parseInt(getVal('vital-dia')) || 80;
  const map = Math.round(dia + (sys - dia) / 3);
  const pr = parseInt(getVal('vital-pr')) || 72;
  const spo2 = parseInt(getVal('vital-spo2')) || 99;
  const etco2 = parseInt(getVal('vital-etco2')) || 35;
  const event = getVal('vital-event') || '';

  if (!activeRecord.vitals) activeRecord.vitals = [];
  activeRecord.vitals.push({ time, sys, dia, map, pr, spo2, etco2, event });
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderVitalsTable();

  // Reset remarks & update time
  setVal('vital-event', '');
  setVal('vital-time', getCurrentTimeHHMM());
  showToast("Hemodynamic stamp recorded");
}

function deleteVitalEntry(idx) {
  if (!activeRecord || !activeRecord.vitals) return;
  activeRecord.vitals.splice(idx, 1);
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderVitalsTable();
}

function renderVitalsTable() {
  const tbody = document.getElementById('vitals-tbody');
  if (!tbody || !activeRecord) return;

  const list = activeRecord.vitals || [];
  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:var(--on-surface-variant); padding:16px;">No hemodynamic stamps recorded yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map((v, i) => `
    <tr>
      <td><strong>${v.time}</strong></td>
      <td>${v.sys}/${v.dia} (${v.map})</td>
      <td>${v.pr} bpm</td>
      <td>${v.spo2}%</td>
      <td>${v.etco2 || '--'}</td>
      <td>${v.event || '—'}</td>
      <td>
        <button class="m3-icon-btn" style="color:var(--error); width:28px; height:28px; font-size:14px;" onclick="deleteVitalEntry(${i})">✕</button>
      </td>
    </tr>
  `).join('');
}

// ==========================================================================
// Intra-Op Drugs (Matching IntraOpDrugsScreen.kt)
// ==========================================================================
function quickFillDrug(name, dose, route) {
  setVal('drug-name', name);
  setVal('drug-dose', dose);
  setVal('drug-route', route);
  setVal('drug-time', getCurrentTimeHHMM());
}

function addDrugEntry() {
  if (!activeRecord) return;
  const name = getVal('drug-name').trim();
  const dose = getVal('drug-dose').trim();
  const route = getVal('drug-route') || 'IV';
  const time = getVal('drug-time') || getCurrentTimeHHMM();

  if (!name || !dose) {
    alert("Please enter both drug name and dose.");
    return;
  }

  if (!activeRecord.drugs) activeRecord.drugs = [];
  activeRecord.drugs.push({ time, name, dose, route });
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderDrugsTable();

  // Reset fields
  setVal('drug-name', '');
  setVal('drug-dose', '');
  setVal('drug-time', getCurrentTimeHHMM());
  showToast("Medication bolus recorded");
}

function deleteDrugEntry(idx) {
  if (!activeRecord || !activeRecord.drugs) return;
  activeRecord.drugs.splice(idx, 1);
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderDrugsTable();
}

function renderDrugsTable() {
  const tbody = document.getElementById('drugs-tbody');
  if (!tbody || !activeRecord) return;

  const list = activeRecord.drugs || [];
  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--on-surface-variant); padding:16px;">No medications recorded yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map((d, i) => `
    <tr>
      <td><strong>${d.time}</strong></td>
      <td>${d.name}</td>
      <td><strong>${d.dose}</strong></td>
      <td>${d.route}</td>
      <td>
        <button class="m3-icon-btn" style="color:var(--error); width:28px; height:28px; font-size:14px;" onclick="deleteDrugEntry(${i})">✕</button>
      </td>
    </tr>
  `).join('');
}

// ==========================================================================
// Intake & Output Management (Matching IOScreen.kt)
// ==========================================================================
function addIoEntry() {
  if (!activeRecord) return;
  const time = getVal('io-entry-time') || getCurrentTimeHHMM();
  const infusion = getVal('io-entry-infusion').trim() || '—';
  const bloodLoss = parseFloat(getVal('io-entry-blood')) || 0;
  const urine = parseFloat(getVal('io-entry-urine')) || 0;
  const temp = parseFloat(getVal('io-entry-temp')) || 98.6;

  if (!activeRecord.ioList) activeRecord.ioList = [];
  activeRecord.ioList.push({ time, infusion, bloodLoss, urine, temp });
  activeRecord.updatedAt = Date.now();
  saveAllRecords();

  renderIoHistoryTable();
  calcIoCumulativeTotals();

  // Reset fields
  setVal('io-entry-infusion', '');
  setVal('io-entry-blood', '');
  setVal('io-entry-urine', '');
  setVal('io-entry-time', getCurrentTimeHHMM());
  showToast("I&O Entry recorded");
}

function openEditIoModal(idx) {
  if (!activeRecord || !activeRecord.ioList || !activeRecord.ioList[idx]) return;
  const entry = activeRecord.ioList[idx];

  setVal('edit-io-index', idx);
  setVal('edit-io-time', entry.time);
  setVal('edit-io-infusion', entry.infusion);
  setVal('edit-io-blood', entry.bloodLoss);
  setVal('edit-io-urine', entry.urine);
  setVal('edit-io-temp', entry.temp);

  openModal('modal-edit-io');
}

function saveEditedIoEntry() {
  if (!activeRecord || !activeRecord.ioList) return;
  const idx = parseInt(getVal('edit-io-index'));
  if (isNaN(idx) || !activeRecord.ioList[idx]) return;

  activeRecord.ioList[idx] = {
    time: getVal('edit-io-time') || getCurrentTimeHHMM(),
    infusion: getVal('edit-io-infusion').trim() || '—',
    bloodLoss: parseFloat(getVal('edit-io-blood')) || 0,
    urine: parseFloat(getVal('edit-io-urine')) || 0,
    temp: parseFloat(getVal('edit-io-temp')) || 98.6
  };

  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderIoHistoryTable();
  calcIoCumulativeTotals();
  closeModal('modal-edit-io');
  showToast("I&O Entry updated");
}

function deleteIoEntry(idx) {
  if (!activeRecord || !activeRecord.ioList) return;
  activeRecord.ioList.splice(idx, 1);
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderIoHistoryTable();
  calcIoCumulativeTotals();
}

function renderIoHistoryTable() {
  const tbody = document.getElementById('io-history-tbody');
  if (!tbody || !activeRecord) return;

  const list = activeRecord.ioList || [];
  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--on-surface-variant); padding:16px;">No I&amp;O records logged yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map((item, i) => `
    <tr>
      <td><strong>${item.time}</strong></td>
      <td>${item.infusion}</td>
      <td>${item.bloodLoss} mL</td>
      <td>${item.urine} mL</td>
      <td>${item.temp ? `${item.temp}°F` : '—'}</td>
      <td style="white-space:nowrap;">
        <button class="m3-icon-btn" style="color:var(--primary); width:28px; height:28px; font-size:13px; display:inline-flex;" onclick="openEditIoModal(${i})" title="Edit">✏️</button>
        <button class="m3-icon-btn" style="color:var(--error); width:28px; height:28px; font-size:13px; display:inline-flex;" onclick="deleteIoEntry(${i})" title="Delete">✕</button>
      </td>
    </tr>
  `).join('');
}

function calcIoCumulativeTotals() {
  if (!activeRecord) return;
  const list = activeRecord.ioList || [];

  let totalInfused = 0;
  let totalBlood = 0;
  let totalUrine = 0;

  list.forEach(item => {
    totalBlood += (parseFloat(item.bloodLoss) || 0);
    totalUrine += (parseFloat(item.urine) || 0);

    // Extract numbers from infusion string (e.g. "500 mL RL" or "500")
    const match = item.infusion.match(/(\d+)\s*(ml|mL)?/);
    if (match) {
      totalInfused += parseFloat(match[1]) || 0;
    }
  });

  const net = totalInfused - (totalBlood + totalUrine);

  setElemText('io-cum-infused', `${totalInfused} mL`);
  setElemText('io-cum-blood', `${totalBlood} mL`);
  setElemText('io-cum-urine', `${totalUrine} mL`);

  const netEl = document.getElementById('io-cum-net');
  if (netEl) {
    netEl.textContent = `${net >= 0 ? '+' : ''}${net} mL`;
    netEl.style.color = net >= 0 ? 'var(--primary)' : 'var(--error)';
  }
}

// ==========================================================================
// Attached Clinical Images & Reports (Matching SummaryScreen.kt)
// ==========================================================================
function handleImageAttachmentUpload(event) {
  if (!activeRecord) return;
  const files = event.target.files;
  if (!files || files.length === 0) return;

  if (!activeRecord.attachments) activeRecord.attachments = [];

  Array.from(files).forEach(file => {
    const reader = new FileReader();
    reader.onload = (e) => {
      activeRecord.attachments.push({
        id: Date.now() + Math.random(),
        name: file.name,
        data: e.target.result,
        uploadedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });
      activeRecord.updatedAt = Date.now();
      saveAllRecords();
      renderImageAttachments();
    };
    reader.readAsDataURL(file);
  });
  showToast("Image attached");
}

function deleteImageAttachment(idx) {
  if (!activeRecord || !activeRecord.attachments) return;
  activeRecord.attachments.splice(idx, 1);
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
  renderImageAttachments();
}

function previewImageAttachment(dataUrl, name) {
  const imgEl = document.getElementById('preview-image-src');
  const titleEl = document.getElementById('preview-image-title');
  if (imgEl) imgEl.src = dataUrl;
  if (titleEl) titleEl.textContent = name || 'Clinical Image Preview';
  openModal('modal-image-preview');
}

function renderImageAttachments() {
  const container = document.getElementById('sum-attachment-gallery');
  const countBadge = document.getElementById('sum-attachment-count');
  if (!container || !activeRecord) return;

  const list = activeRecord.attachments || [];
  if (countBadge) countBadge.textContent = list.length;

  if (list.length === 0) {
    container.innerHTML = `<div style="font-size:12px; color:var(--on-surface-variant); padding:8px 0;">No images attached yet. Tap "+ Attach Image" to upload radiographs, ECGs, or lab reports.</div>`;
    return;
  }

  container.innerHTML = list.map((att, i) => `
    <div class="m3-attachment-card">
      <img src="${att.data}" alt="${att.name}" class="m3-attachment-thumb" onclick="previewImageAttachment('${att.data}', '${att.name}')">
      <div class="m3-attachment-name" title="${att.name}">${att.name}</div>
      <button class="m3-attachment-del" onclick="deleteImageAttachment(${i})" title="Remove image">✕</button>
    </div>
  `).join('');
}

function autoSaveRecordComments() {
  if (!activeRecord) return;
  activeRecord.comments = getVal('sum-comments-input');
  activeRecord.updatedAt = Date.now();
  saveAllRecords();
}

function saveRecordCommentsExplicit() {
  autoSaveRecordComments();
  showToast("Comments saved to record");
}

// ==========================================================================
// Comprehensive Case Summary (Matching SummaryScreen.kt)
// ==========================================================================
function renderCaseSummary() {
  if (!activeRecord) return;

  // Header Doctor
  const doc = getSavedDoctorProfile();
  setSummaryText('summary-doc-header', `${doc.name || 'Dr. Abul Hasnat Khan'} · ${doc.bmdc ? `BMDC: ${doc.bmdc}` : 'Consultant Anesthesiologist'}`);
  setSummaryText('summary-hospital-header', `${doc.institute || 'Department of Anesthesia, Critical Care & Pain Medicine'}`);

  // Demographics
  setSummaryText('sum-name', activeRecord.name);
  setSummaryText('sum-reg', activeRecord.regNo);
  setSummaryText('sum-age-sex', `${activeRecord.age} Y / ${activeRecord.sex}`);
  setSummaryText('sum-bg', activeRecord.bg);
  setSummaryText('sum-wt-ht', `${activeRecord.weight} kg / ${activeRecord.height} cm`);
  setSummaryText('sum-ward', `${activeRecord.ward || '—'} / ${activeRecord.bed || '—'}`);
  setSummaryText('sum-dates', `DOA: ${activeRecord.doa || '—'} · DOO: ${activeRecord.doo || '—'}`);
  setSummaryText('sum-asa', `${activeRecord.asa} ${activeRecord.emergency ? '(Emergency - E)' : ''}`);
  setSummaryText('sum-mallampati', `${activeRecord.mallampati} (Mouth: ${activeRecord.mouthOpening || '—'})`);
  setSummaryText('sum-diagnosis', activeRecord.diagnosis);
  setSummaryText('sum-surgery', activeRecord.surgery);

  // Comorbidities & Risk Factors
  const comBox = document.getElementById('sum-comorbidities-box');
  if (comBox) {
    const list = activeRecord.comorbidities || [];
    const allergies = activeRecord.allergies || 'None known';
    comBox.innerHTML = `
      <div><strong>Comorbidities:</strong> ${list.length > 0 ? list.join(', ') : 'None documented'}</div>
      <div><strong>Allergies:</strong> <span style="color:var(--error); font-weight:600;">${allergies}</span></div>
    `;
  }

  // Pre-Op Investigations
  const invBox = document.getElementById('sum-investigations-box');
  if (invBox) {
    const inv = activeRecord.inv || {};
    const sero = inv.serology || {};
    const custom = (inv.customLabs || []).map(c => `${c.name}: ${c.value} ${c.unit || ''}`).join(' · ');

    invBox.innerHTML = `
      <div><strong>CBC:</strong> Hb: ${inv.hb || '—'} g/dL · Platelets: ${inv.platelet || '—'} · WBC: ${inv.wbc || '—'} · ESR: ${inv.esr || '—'}</div>
      <div><strong>Coagulation:</strong> PT: ${inv.pt || '—'} s · INR: ${inv.inr || '—'} · APTT: ${inv.aptt || '—'} s</div>
      <div><strong>RFT &amp; LFT:</strong> Creatinine: ${inv.creatinine || '—'} mg/dL · Urea: ${inv.urea || '—'} · SGPT: ${inv.sgpt || '—'} U/L · Bilirubin: ${inv.bili || '—'}</div>
      <div><strong>Electrolytes &amp; RBS:</strong> Na+: ${inv.na || '—'} · K+: ${inv.k || '—'} · Cl-: ${inv.cl || '—'} · RBS: ${inv.rbs || '—'} mmol/L</div>
      <div><strong>Serology:</strong> HBsAg: ${sero.hbsag || 'Negative'} · HCV: ${sero.hcv || 'Negative'} · HIV: ${sero.hiv || 'Negative'} · VDRL: ${sero.vdrl || 'Non-reactive'}</div>
      ${inv.ecg ? `<div><strong>ECG:</strong> ${inv.ecg}</div>` : ''}
      ${inv.cxr ? `<div><strong>Chest X-Ray:</strong> ${inv.cxr}</div>` : ''}
      ${inv.echo ? `<div><strong>Echocardiogram:</strong> ${inv.echo}</div>` : ''}
      ${custom ? `<div><strong>Other Tests:</strong> ${custom}</div>` : ''}
    `;
  }

  // Technique & Team
  const techBox = document.getElementById('sum-technique-box');
  if (techBox) {
    const t = activeRecord.technique || {};
    const gas = activeRecord.gases || {};
    const isRegional = t.category === 'regional';

    if (isRegional) {
      const regDrugs = (t.regDrugs || []).map(d => `${d.name} (${d.dose} ${d.unit})`).join(', ');
      techBox.innerHTML = `
        <div><strong>Technique:</strong> ${t.regType || 'Spinal Anesthesia'} (Space: ${t.regSite || 'L3-L4'}, Induction: ${t.regTime || '—'}, Position: ${t.regPosition || '—'})</div>
        <div><strong>Injected Drugs:</strong> ${regDrugs || '—'}</div>
        <div><strong>Team:</strong> Attending: ${t.attending || '—'} ${t.supervision === 'supervised' ? ` · Supervisor: ${t.consultant || '—'}` : ''}</div>
      `;
    } else {
      techBox.innerHTML = `
        <div><strong>Technique:</strong> General Anesthesia (${t.gaSubtype || 'Combined'}) · Airway: ${t.gaRoute || 'ETT'} (Size: ${t.gaSize || '7.5'}, Length: ${t.gaLength || '21cm'})</div>
        <div><strong>Ventilation:</strong> Circuit: ${t.gaCircuit || 'Circle'} · TV: ${t.gaTv || '450'} mL · RR: ${t.gaRr || '12'} · I:E: ${t.gaIe || '1:2'} · Position: ${t.gaPosition || 'Supine'}</div>
        <div><strong>Fresh Gas &amp; Vaporizer:</strong> O2: ${gas.o2 || '2.0'} L/min · Air: ${gas.air || '2.0'} L/min · Agent: ${gas.agent || 'Isoflurane'} (${gas.pct || '1.2'}%)</div>
        <div><strong>Team:</strong> Attending: ${t.attending || '—'} ${t.supervision === 'supervised' ? ` · Supervisor: ${t.consultant || '—'}` : ''}</div>
      `;
    }
  }

  // Intra-Op Vitals
  const vitalsTbody = document.getElementById('sum-vitals-tbody');
  if (vitalsTbody) {
    const list = activeRecord.vitals || [];
    vitalsTbody.innerHTML = list.length === 0 ?
      `<tr><td colspan="6" style="text-align:center; color:var(--on-surface-variant); padding:10px;">No hemodynamics recorded.</td></tr>` :
      list.map(v => `<tr><td>${v.time}</td><td>${v.sys}/${v.dia} (${v.map})</td><td>${v.pr}</td><td>${v.spo2}%</td><td>${v.etco2 || '--'}</td><td>${v.event || '—'}</td></tr>`).join('');
  }

  // Medications
  const drugsTbody = document.getElementById('sum-drugs-tbody');
  if (drugsTbody) {
    const list = activeRecord.drugs || [];
    drugsTbody.innerHTML = list.length === 0 ?
      `<tr><td colspan="4" style="text-align:center; color:var(--on-surface-variant); padding:10px;">No medications recorded.</td></tr>` :
      list.map(d => `<tr><td>${d.time}</td><td>${d.name}</td><td>${d.dose}</td><td>${d.route}</td></tr>`).join('');
  }

  // I&O
  const ioBox = document.getElementById('sum-io-box');
  if (ioBox) {
    const list = activeRecord.ioList || [];
    let totalInfused = 0, totalBlood = 0, totalUrine = 0;
    list.forEach(i => {
      totalBlood += (parseFloat(i.bloodLoss) || 0);
      totalUrine += (parseFloat(i.urine) || 0);
      const m = i.infusion.match(/(\d+)/);
      if (m) totalInfused += parseFloat(m[1]) || 0;
    });
    const net = totalInfused - (totalBlood + totalUrine);

    ioBox.innerHTML = `
      <div><strong>Total Infused:</strong> ${totalInfused} mL · <strong>Total Blood Loss:</strong> ${totalBlood} mL · <strong>Total Urine:</strong> ${totalUrine} mL</div>
      <div><strong>Cumulative Fluid Balance:</strong> <strong style="color:${net >= 0 ? 'var(--primary)' : 'var(--error)'}; font-size:13.5px;">${net >= 0 ? '+' : ''}${net} mL</strong></div>
    `;
  }

  // Signatures
  const attendingSig = document.getElementById('sum-sig-attending');
  const consultantSig = document.getElementById('sum-sig-consultant');
  const t = activeRecord.technique || {};
  if (attendingSig) attendingSig.textContent = t.attending || doc.name || 'Dr. Abul Hasnat Khan';
  if (consultantSig) consultantSig.textContent = t.supervision === 'supervised' ? (t.consultant || 'Supervising Consultant') : 'Consultant / HOD';
}

function setSummaryText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text || '—';
}

function printCaseRecord() {
  window.print();
}

function copyCaseRecordText() {
  if (!activeRecord) return;
  const doc = getSavedDoctorProfile();
  const summary = `
=========================================
PERIOPERATIVE ANESTHESIA CLINICAL RECORD
${doc.name || 'Dr. Abul Hasnat Khan'} · ${doc.institute || 'Consultant Anesthesiologist'}
=========================================
Patient: ${activeRecord.name} (Reg: ${activeRecord.regNo})
Age/Sex: ${activeRecord.age}Y / ${activeRecord.sex} | Blood Group: ${activeRecord.bg}
Weight: ${activeRecord.weight} kg | Height: ${activeRecord.height} cm
Ward/Bed: ${activeRecord.ward || '—'} / ${activeRecord.bed || '—'}
Diagnosis: ${activeRecord.diagnosis}
Surgery: ${activeRecord.surgery}
ASA Status: ${activeRecord.asa} ${activeRecord.emergency ? '(Emergency)' : ''}
Mallampati: ${activeRecord.mallampati} | Allergies: ${activeRecord.allergies || 'None'}
Comorbidities: ${(activeRecord.comorbidities || []).join(', ') || 'None'}

Technique: ${activeRecord.technique?.category === 'regional' ? activeRecord.technique?.regType : activeRecord.technique?.gaSubtype || 'General Anesthesia'}
Attending Anesthesiologist: ${activeRecord.technique?.attending || doc.name}

Hemodynamics:
${(activeRecord.vitals || []).map(v => `${v.time} - BP: ${v.sys}/${v.dia} (MAP ${v.map}), PR: ${v.pr}, SpO2: ${v.spo2}%, Event: ${v.event || 'None'}`).join('\n')}

Medications Administered:
${(activeRecord.drugs || []).map(d => `${d.time} - ${d.name} ${d.dose} (${d.route})`).join('\n')}

Fluid Balance:
${(activeRecord.ioList || []).map(i => `${i.time} - ${i.infusion} | Loss: ${i.bloodLoss}mL | Urine: ${i.urine}mL`).join('\n')}
=========================================
  `.trim();

  navigator.clipboard.writeText(summary).then(() => {
    showToast("Case record copied to clipboard!");
  }).catch(() => {
    alert("Could not copy automatically. You can print or save as PDF.");
  });
}

// ==========================================================================
// Floating Action Button & Speed Dial
// ==========================================================================
function toggleSpeedDial() {
  const menu = document.getElementById('speed-dial-menu');
  const backdrop = document.getElementById('fab-backdrop');
  const fabBtn = document.getElementById('fab-main-btn');

  if (menu && backdrop && fabBtn) {
    const isOpen = menu.classList.contains('open');
    if (isOpen) {
      menu.classList.remove('open');
      backdrop.classList.remove('active');
      fabBtn.classList.remove('rotated');
    } else {
      menu.classList.add('open');
      backdrop.classList.add('active');
      fabBtn.classList.add('rotated');
    }
  }
}

// ==========================================================================
// Theme & Accent Switcher (Matching Android Theme.kt)
// ==========================================================================
function loadThemeSettings() {
  const savedTheme = localStorage.getItem(STORAGE_KEY_THEME) || 'light';
  const savedAccent = localStorage.getItem(STORAGE_KEY_ACCENT) || 'teal';
  setAppTheme(savedTheme);
  setAppAccent(savedAccent);
}

function setAppTheme(mode) {
  localStorage.setItem(STORAGE_KEY_THEME, mode);
  const root = document.documentElement;

  if (mode === 'dark') {
    root.setAttribute('data-theme', 'dark');
  } else if (mode === 'light') {
    root.removeAttribute('data-theme');
  } else {
    // System Default
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      root.setAttribute('data-theme', 'dark');
    } else {
      root.removeAttribute('data-theme');
    }
  }
}

function setAppAccent(accent) {
  localStorage.setItem(STORAGE_KEY_ACCENT, accent);
  document.documentElement.setAttribute('data-accent', accent);
}

// ==========================================================================
// Doctor Profile Management
// ==========================================================================
function getSavedDoctorProfile() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_DOCTOR);
    return raw ? JSON.parse(raw) : { name: "Dr. Abul Hasnat Khan", institute: "Consultant Anesthesiologist" };
  } catch (e) {
    return { name: "Dr. Abul Hasnat Khan", institute: "Consultant Anesthesiologist" };
  }
}

function loadDoctorProfile() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_DOCTOR);
    if (raw) {
      const doc = JSON.parse(raw);
      setVal('doc-name', doc.name);
      setVal('doc-phone', doc.phone);
      setVal('doc-email', doc.email);
      setVal('doc-institute', doc.institute);
      setVal('doc-bmdc', doc.bmdc);

      const headerDoc = document.getElementById('summary-doc-header');
      if (headerDoc && doc.name) {
        headerDoc.textContent = `${doc.name} · ${doc.institute || 'Consultant Anesthesiologist'}`;
      }

      // Check admin status
      if (doc.email === 'hasnatraju3@gmail.com' || doc.email === 'tsalmanrahman55@gmail.com') {
        const adminBtn = document.getElementById('speed-dial-admin-btn');
        if (adminBtn) adminBtn.style.display = 'flex';
      }
    }
  } catch (e) {}
}

function saveDoctorProfile() {
  const doc = {
    name: getVal('doc-name'),
    phone: getVal('doc-phone'),
    email: getVal('doc-email'),
    institute: getVal('doc-institute'),
    bmdc: getVal('doc-bmdc')
  };
  localStorage.setItem(STORAGE_KEY_DOCTOR, JSON.stringify(doc));
  loadDoctorProfile();
  closeModal('modal-doctor');
  showToast("Doctor profile saved");
}

// ==========================================================================
// Backup & Restore (JSON)
// ==========================================================================
function exportDataJSON() {
  const payload = {
    version: "2.0",
    exportDate: new Date().toISOString(),
    doctor: getSavedDoctorProfile(),
    records: allRecords
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `AnesthesiaAid_Backup_${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast("Database exported as JSON");
}

function importDataJSON(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      if (data.records && Array.isArray(data.records)) {
        if (confirm(`Import ${data.records.length} records? This will merge with your existing database.`)) {
          allRecords = [...data.records, ...allRecords];
          saveAllRecords();
          closeModal('modal-backup');
          showToast("Database imported successfully");
        }
      } else {
        alert("Invalid backup file format.");
      }
    } catch (err) {
      alert("Error reading backup file: " + err.message);
    }
  };
  reader.readAsText(file);
}

// ==========================================================================
// bKash Subscription
// ==========================================================================
function submitTrxID() {
  const trx = getVal('sub-trx-id').trim();
  if (!trx) {
    alert("Please enter your bKash Transaction ID.");
    return;
  }
  alert(`Thank you! TrxID "${trx}" submitted for administrator verification.`);
  closeModal('modal-subscription');
}

// ==========================================================================
// Modals & Toast Helper
// ==========================================================================
function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add('active');
}

function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove('active');
}

function closeModalOnOutside(e, id) {
  if (e.target && e.target.id === id) {
    closeModal(id);
  }
}

function showToast(msg) {
  const toast = document.getElementById('app-toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 2800);
}

// ==========================================================================
// iOS Safari Add to Home Screen Banner
// ==========================================================================
function initIosInstallBanner() {
  const isIos = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
  const isStandalone = window.navigator.standalone || window.matchMedia('(display-mode: standalone)').matches;
  const isDismissed = localStorage.getItem(STORAGE_KEY_IOS_DISMISSED);

  if (isIos && !isStandalone && !isDismissed) {
    const banner = document.getElementById('ios-install-banner');
    if (banner) banner.style.display = 'flex';
  }
}

function dismissIosBanner() {
  localStorage.setItem(STORAGE_KEY_IOS_DISMISSED, 'true');
  const banner = document.getElementById('ios-install-banner');
  if (banner) banner.style.display = 'none';
}
