// Anesthesia Aid - Progressive Web App Core Engine
// Compatible with GitHub Pages and Android WebAPK standalone mode

const STORAGE_KEY = 'anesthesia_records_db';
const USER_KEY = 'anesthesia_user_session';

// Default empty template for a patient record
function createEmptyRecord() {
  return {
    id: Date.now().toString(),
    name: "New Patient",
    reg: "",
    date: new Date().toISOString().split('T')[0],
    age: 45,
    sex: "Male",
    weight: 60,
    height: 165,
    bmi: 22.0,
    bsa: 1.66,
    ibw: 60.0,
    asa: "ASA I",
    mallampati: "Class I",
    npo: "8 hrs solids, 2 hrs liquids",
    urgency: "Elective",
    diagnosis: "",
    operation: "",
    surgeon: "",
    anesthesiologist: "",
    hb: 12.5,
    platelet: 250,
    bg: "O+",
    rbs: 6.5,
    creatinine: 0.9,
    electrolytes: "138 / 4.2",
    ptInr: "PT 12s, INR 1.0",
    sgpt: 30,
    ecg: "Normal Sinus Rhythm",
    cxr: "Clear",
    technique: "GA",
    ett: "7.5 mm Cuffed",
    lma: "Size 4",
    inhalational: "Isoflurane",
    circuit: "Circle System",
    regType: "Subarachnoid Block (SAB)",
    regNeedle: "25G Quincke",
    regSpace: "L3-L4",
    regDrug: "0.5% Bupivacaine Heavy 3.0 mL",
    regAdjuvant: "",
    vitals: [],
    drugs: [],
    ioCrys: 1000,
    ioColl: 0,
    ioBlood: 0,
    ioFfp: 0,
    ioUrine: 250,
    ioLoss: 150
  };
}

let recordsList = [];
let activeRecord = null;
let currentDoctor = {
  name: "Dr. Clinician",
  email: "doctor@example.com",
  status: "APPROVED",
  role: "USER"
};

// --- Initialization ---
document.addEventListener("DOMContentLoaded", () => {
  loadRecordsFromStorage();
  loadUserSession();
  registerServiceWorker();
  
  // Set default vitals time to current
  const timeInput = document.getElementById('v-time');
  if (timeInput) {
    const now = new Date();
    timeInput.value = now.toTimeString().substring(0, 5);
  }

  // Render initial calculations and screen
  calculateBMIAndDoses();
  calcIOBalance();
});

// --- Service Worker Registration (Relative path for GitHub Pages) ---
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js')
      .then(() => console.log('Anesthesia Aid SW Registered (Offline Ready)'))
      .catch(err => console.log('SW registration error:', err));
  }
}

// --- User Session & Auth ---
function loadUserSession() {
  const saved = localStorage.getItem(USER_KEY);
  if (saved) {
    try {
      currentDoctor = JSON.parse(saved);
    } catch (e) {}
  }
  updateDoctorUI();
}

function updateDoctorUI() {
  const nameDisplay = document.getElementById('doc-name-display');
  if (nameDisplay) nameDisplay.textContent = currentDoctor.name || "Clinician";
  
  const adminBtn = document.getElementById('btn-admin');
  if (adminBtn) {
    adminBtn.style.display = (currentDoctor.email === 'hasnatraju3@gmail.com' || currentDoctor.email === 'tsalmanrahman55@gmail.com' || currentDoctor.role === 'ADMIN') ? 'inline-flex' : 'none';
  }
}

function handleLogin() {
  const email = document.getElementById('login-email').value.trim();
  if (email) {
    currentDoctor.email = email;
    currentDoctor.name = email.split('@')[0];
    if (email === 'hasnatraju3@gmail.com' || email === 'tsalmanrahman55@gmail.com') {
      currentDoctor.role = 'ADMIN';
    }
  }
  localStorage.setItem(USER_KEY, JSON.stringify(currentDoctor));
  updateDoctorUI();
  showScreen('screen-records');
}

function handleQuickSkip() {
  currentDoctor.name = "Guest Clinician";
  currentDoctor.status = "TRIAL";
  localStorage.setItem(USER_KEY, JSON.stringify(currentDoctor));
  updateDoctorUI();
  showScreen('screen-records');
}

function handleRegistrationSubmit() {
  const name = document.getElementById('reg-name').value.trim();
  const phone = document.getElementById('reg-phone').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  if (name) currentDoctor.name = name;
  if (email) currentDoctor.email = email;
  localStorage.setItem(USER_KEY, JSON.stringify(currentDoctor));
  showScreen('screen-subscription');
}

function handleSubscriptionSubmit() {
  showScreen('screen-pending');
}

function handleSignOut() {
  closeDoctorModalDirect();
  showScreen('screen-onboarding');
}

// --- Data Persistence ---
function loadRecordsFromStorage() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw) {
    try {
      recordsList = JSON.parse(raw);
    } catch (e) {
      recordsList = [];
    }
  }
  if (!recordsList || recordsList.length === 0) {
    const defaultRec = createEmptyRecord();
    recordsList = [defaultRec];
  }
  activeRecord = recordsList[0];
  populateUIFromRecord(activeRecord);
  renderRecordsList();
  updateHeaderPatientName();
}

function saveRecordsToStorage() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(recordsList));
  renderRecordsList();
  updateHeaderPatientName();
}

function createNewCase() {
  const newRec = createEmptyRecord();
  newRec.name = `Patient #${recordsList.length + 1}`;
  recordsList.unshift(newRec);
  activeRecord = newRec;
  saveRecordsToStorage();
  populateUIFromRecord(activeRecord);
  showScreen('screen-particulars');
}

function selectRecord(id) {
  const found = recordsList.find(r => r.id === id);
  if (found) {
    activeRecord = found;
    populateUIFromRecord(activeRecord);
    saveRecordsToStorage();
    showScreen('screen-particulars');
  }
}

function deleteRecord(id, event) {
  if (event) event.stopPropagation();
  if (confirm("Are you sure you want to delete this anesthesia case?")) {
    recordsList = recordsList.filter(r => r.id !== id);
    if (recordsList.length === 0) {
      recordsList.push(createEmptyRecord());
    }
    activeRecord = recordsList[0];
    saveRecordsToStorage();
    populateUIFromRecord(activeRecord);
  }
}

function updateActiveRecordField(field, value) {
  if (!activeRecord) return;
  activeRecord[field] = value;
  saveRecordsToStorage();
}

// Populate Form Inputs from Active Record
function populateUIFromRecord(r) {
  if (!r) return;
  setVal('p-name', r.name || '');
  setVal('p-reg', r.reg || '');
  setVal('p-date', r.date || '');
  setVal('p-age', r.age || 45);
  setVal('p-sex', r.sex || 'Male');
  setVal('p-weight', r.weight || 60);
  setVal('p-height', r.height || 165);
  setVal('p-asa', r.asa || 'ASA I');
  setVal('p-mallampati', r.mallampati || 'Class I');
  setVal('p-npo', r.npo || '');
  setVal('p-urgency', r.urgency || 'Elective');
  setVal('p-diagnosis', r.diagnosis || '');
  setVal('p-operation', r.operation || '');
  setVal('p-surgeon', r.surgeon || '');
  setVal('p-anesthesiologist', r.anesthesiologist || '');

  setVal('inv-hb', r.hb || 12.5);
  setVal('inv-platelet', r.platelet || 250);
  setVal('inv-bg', r.bg || 'O+');
  setVal('inv-rbs', r.rbs || 6.5);
  setVal('inv-creatinine', r.creatinine || 0.9);
  setVal('inv-electrolytes', r.electrolytes || '138 / 4.2');
  setVal('inv-pt', r.ptInr || 'PT 12s, INR 1.0');
  setVal('inv-sgpt', r.sgpt || 30);
  setVal('inv-ecg', r.ecg || 'Normal');
  setVal('inv-cxr', r.cxr || 'Clear');

  setVal('tech-type', r.technique || 'GA');
  setVal('airway-ett', r.ett || '7.5 mm Cuffed');
  setVal('airway-lma', r.lma || 'Size 4');
  setVal('ga-gas', r.inhalational || 'Isoflurane');
  setVal('ga-circuit', r.circuit || 'Circle System');
  setVal('reg-type', r.regType || 'Subarachnoid Block (SAB)');
  setVal('reg-needle', r.regNeedle || '25G Quincke');
  setVal('reg-space', r.regSpace || 'L3-L4');
  setVal('reg-drug', r.regDrug || '0.5% Bupivacaine Heavy 3.0 mL');
  setVal('reg-adjuvant', r.regAdjuvant || '');

  setVal('io-crys', r.ioCrys || 1000);
  setVal('io-coll', r.ioColl || 0);
  setVal('io-blood', r.ioBlood || 0);
  setVal('io-ffp', r.ioFfp || 0);
  setVal('io-urine', r.ioUrine || 250);
  setVal('io-loss', r.ioLoss || 150);

  toggleTechniqueUI();
  renderVitalsTable();
  renderDrugsTable();
  calculateBMIAndDoses();
  calcIOBalance();
  updateHeaderPatientName();
}

function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val;
}

function updateHeaderPatientName() {
  const pill = document.getElementById('header-patient-name');
  if (pill && activeRecord) {
    pill.textContent = activeRecord.name ? `👤 ${activeRecord.name}` : `👤 Case #${activeRecord.id.slice(-4)}`;
  }
}

// --- Navigation Engine (Syncs Top Tabs & Bottom Quick Nav) ---
function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = document.getElementById(screenId);
  if (target) {
    target.classList.add('active');
  }

  // Scroll to top of content
  const main = document.querySelector('main');
  if (main) main.scrollTop = 0;

  // Sync Top Tab Row
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  const tabMap = {
    'screen-records': 'tab-records',
    'screen-particulars': 'tab-particulars',
    'screen-investigations': 'tab-investigations',
    'screen-calculator': 'tab-calculator',
    'screen-technique': 'tab-technique',
    'screen-vitals': 'tab-vitals',
    'screen-drugs': 'tab-drugs',
    'screen-io': 'tab-io',
    'screen-summary': 'tab-summary'
  };
  const activeTabId = tabMap[screenId];
  if (activeTabId) {
    const activeTab = document.getElementById(activeTabId);
    if (activeTab) {
      activeTab.classList.add('active');
      activeTab.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    }
  }

  // Sync Bottom Nav Bar
  document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
  const bnavMap = {
    'screen-records': 'bnav-records',
    'screen-particulars': 'bnav-particulars',
    'screen-calculator': 'bnav-calculator',
    'screen-vitals': 'bnav-vitals',
    'screen-summary': 'bnav-summary'
  };
  const bnavId = bnavMap[screenId];
  if (bnavId) {
    document.getElementById(bnavId)?.classList.add('active');
  }

  if (screenId === 'screen-summary') {
    renderSummarySheet();
  }
}

// --- Clinical Calculators Engine ---
function calculateBMIAndDoses() {
  if (!activeRecord) return;
  const wt = parseFloat(activeRecord.weight) || 60;
  const ht = parseFloat(activeRecord.height) || 165;
  const age = parseFloat(activeRecord.age) || 45;
  const sex = activeRecord.sex || 'Male';

  // 1. BMI
  const htM = ht / 100;
  const bmi = (wt / (htM * htM)).toFixed(1);
  activeRecord.bmi = bmi;
  const bmiDisplay = document.getElementById('p-bmi-display');
  if (bmiDisplay) bmiDisplay.textContent = `${bmi} kg/m²`;

  // 2. BSA (Mosteller)
  const bsa = Math.sqrt((ht * wt) / 3600).toFixed(2);
  activeRecord.bsa = bsa;
  const bsaDisplay = document.getElementById('p-bsa-display');
  if (bsaDisplay) bsaDisplay.textContent = `${bsa} m²`;

  // 3. Ideal Body Weight (Devine)
  let ibw = 50;
  if (ht > 152.4) {
    const inchesOver5ft = (ht - 152.4) / 2.54;
    ibw = sex === 'Male' ? (50 + 2.3 * inchesOver5ft) : (45.5 + 2.3 * inchesOver5ft);
  }
  activeRecord.ibw = ibw.toFixed(1);
  const ibwDisplay = document.getElementById('p-ibw-display');
  if (ibwDisplay) ibwDisplay.textContent = `${ibw.toFixed(1)} kg`;

  // 4. Fluid Maintenance (4-2-1 Rule)
  let maint = 0;
  if (wt <= 10) maint = wt * 4;
  else if (wt <= 20) maint = 40 + (wt - 10) * 2;
  else maint = 60 + (wt - 20) * 1;
  const maintDisplay = document.getElementById('calc-maint-fluid');
  if (maintDisplay) maintDisplay.textContent = `${Math.round(maint)} mL/hr`;

  // 5. EBV & MABL
  const ebvFactor = age < 1 ? 80 : (sex === 'Male' ? 75 : 65);
  const ebv = Math.round(wt * ebvFactor);
  const ebvDisplay = document.getElementById('calc-ebv');
  if (ebvDisplay) ebvDisplay.textContent = `${ebv} mL`;

  const initHb = parseFloat(activeRecord.hb) || 12.5;
  const targetHb = 10.0;
  let abl = 0;
  if (initHb > targetHb) {
    abl = Math.round(ebv * ((initHb - targetHb) / initHb));
  }
  const ablDisplay = document.getElementById('calc-abl');
  if (ablDisplay) ablDisplay.textContent = `${abl > 0 ? abl : 0} mL`;

  // 6. Pediatric Formulas
  const pedDisplay = document.getElementById('calc-pediatric-ett');
  if (pedDisplay) {
    if (age < 12) {
      const uncuffed = ((age / 4) + 4).toFixed(1);
      const cuffed = ((age / 4) + 3.5).toFixed(1);
      const depth = ((age / 2) + 12).toFixed(1);
      pedDisplay.textContent = `Uncuffed: ${uncuffed} mm | Cuffed: ${cuffed} mm | Depth at lip: ${depth} cm`;
    } else {
      pedDisplay.textContent = `Adult patient (${age}y): Use standard 7.0 - 8.0 mm ETT (Depth: 20-22 cm)`;
    }
  }

  // 7. Drug Dosing Matrix Table
  const activeWtLabel = document.getElementById('calc-active-wt');
  if (activeWtLabel) activeWtLabel.textContent = `${wt} kg (${sex})`;

  renderDoseTable(wt);
}

function renderDoseTable(wt) {
  const tbody = document.getElementById('dose-table-body');
  if (!tbody) return;

  const drugs = [
    { name: "Propofol (Induction)", rule: "1.5 - 2.5 mg/kg", dose: `${Math.round(wt * 1.5)} - ${Math.round(wt * 2.5)} mg` },
    { name: "Ketamine (Induction)", rule: "1.0 - 2.0 mg/kg", dose: `${Math.round(wt * 1.0)} - ${Math.round(wt * 2.0)} mg` },
    { name: "Etomidate", rule: "0.2 - 0.3 mg/kg", dose: `${(wt * 0.2).toFixed(1)} - ${(wt * 0.3).toFixed(1)} mg` },
    { name: "Thiopental", rule: "3.0 - 5.0 mg/kg", dose: `${Math.round(wt * 3.0)} - ${Math.round(wt * 5.0)} mg` },
    { name: "Suxamethonium (Sch)", rule: "1.0 - 1.5 mg/kg", dose: `${Math.round(wt * 1.0)} - ${Math.round(wt * 1.5)} mg` },
    { name: "Rocuronium", rule: "0.6 - 1.2 mg/kg", dose: `${(wt * 0.6).toFixed(1)} - ${(wt * 1.2).toFixed(1)} mg` },
    { name: "Atracurium", rule: "0.5 mg/kg", dose: `${(wt * 0.5).toFixed(1)} mg (Bolus)` },
    { name: "Vecuronium", rule: "0.1 mg/kg", dose: `${(wt * 0.1).toFixed(1)} mg` },
    { name: "Neostigmine Reversal", rule: "0.05 mg/kg", dose: `${(wt * 0.05).toFixed(2)} mg` },
    { name: "Glycopyrrolate", rule: "0.01 mg/kg", dose: `${(wt * 0.01).toFixed(2)} mg` },
    { name: "Sugammadex (Mod Block)", rule: "2.0 mg/kg", dose: `${Math.round(wt * 2.0)} mg` },
    { name: "Fentanyl (Analgesia)", rule: "1.0 - 2.0 mcg/kg", dose: `${Math.round(wt * 1.0)} - ${Math.round(wt * 2.0)} mcg` },
    { name: "Morphine", rule: "0.1 mg/kg", dose: `${(wt * 0.1).toFixed(1)} mg` },
    { name: "Pethidine", rule: "0.5 - 1.0 mg/kg", dose: `${Math.round(wt * 0.5)} - ${Math.round(wt * 1.0)} mg` },
    { name: "Paracetamol IV", rule: "15 mg/kg (Max 1g)", dose: `${Math.min(1000, Math.round(wt * 15))} mg` },
    { name: "Bupivacaine Max (Plain)", rule: "2.0 mg/kg Max", dose: `${Math.round(wt * 2.0)} mg (Max)` },
    { name: "Lidocaine Max (Plain)", rule: "3.0 mg/kg Max", dose: `${Math.round(wt * 3.0)} mg (Max)` },
    { name: "Lidocaine with Adrenaline", rule: "7.0 mg/kg Max", dose: `${Math.round(wt * 7.0)} mg (Max)` }
  ];

  tbody.innerHTML = drugs.map(d => `
    <tr>
      <td><strong>${d.name}</strong></td>
      <td style="color:#64748B;">${d.rule}</td>
      <td style="color:var(--primary); font-weight:700;">${d.dose}</td>
    </tr>
  `).join('');
}

// --- Technique & Airway UI Toggle ---
function toggleTechniqueUI() {
  const val = document.getElementById('tech-type')?.value;
  const gaBox = document.getElementById('ga-fields');
  const regBox = document.getElementById('regional-fields');
  if (gaBox) gaBox.style.display = (val === 'GA' || val === 'Combined') ? 'block' : 'none';
  if (regBox) regBox.style.display = (val === 'Regional' || val === 'Combined') ? 'block' : 'none';
}

// --- Intra-Op Vitals Engine ---
function addVitalEntry() {
  if (!activeRecord) return;
  const time = document.getElementById('v-time').value || new Date().toTimeString().substring(0, 5);
  const sys = parseInt(document.getElementById('v-sys').value) || 120;
  const dia = parseInt(document.getElementById('v-dia').value) || 80;
  const pulse = parseInt(document.getElementById('v-pulse').value) || 75;
  const spo2 = parseInt(document.getElementById('v-spo2').value) || 99;
  const etco2 = parseInt(document.getElementById('v-etco2').value) || 36;
  const map = Math.round((sys + 2 * dia) / 3);

  activeRecord.vitals.push({ id: Date.now(), time, sys, dia, map, pulse, spo2, etco2 });
  saveRecordsToStorage();
  renderVitalsTable();
}

function deleteVitalEntry(id) {
  if (!activeRecord) return;
  activeRecord.vitals = activeRecord.vitals.filter(v => v.id !== id);
  saveRecordsToStorage();
  renderVitalsTable();
}

function renderVitalsTable() {
  const tbody = document.getElementById('vitals-table-body');
  if (!tbody || !activeRecord) return;

  if (activeRecord.vitals.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:#94A3B8; padding:16px;">No vitals logged yet. Tap button above to add.</td></tr>`;
    return;
  }

  tbody.innerHTML = activeRecord.vitals.map(v => `
    <tr>
      <td>${v.time}</td>
      <td>${v.sys}/${v.dia}</td>
      <td><span style="font-weight:700; color:var(--primary);">${v.map}</span></td>
      <td>${v.pulse}</td>
      <td>${v.spo2}%</td>
      <td>${v.etco2 || '--'}</td>
      <td><button class="btn-del" onclick="deleteVitalEntry(${v.id})">✕</button></td>
    </tr>
  `).join('');
}

// --- Intra-Op Medication Log Engine ---
function quickAddDrug(name, dose) {
  if (!activeRecord) return;
  const time = new Date().toTimeString().substring(0, 5);
  activeRecord.drugs.push({ id: Date.now(), time, name, dose });
  saveRecordsToStorage();
  renderDrugsTable();
}

function addDrugEntry() {
  if (!activeRecord) return;
  const name = document.getElementById('d-name').value.trim();
  const dose = document.getElementById('d-dose').value.trim();
  if (!name) return;

  const time = new Date().toTimeString().substring(0, 5);
  activeRecord.drugs.push({ id: Date.now(), time, name, dose: dose || "Given" });
  saveRecordsToStorage();
  renderDrugsTable();

  document.getElementById('d-name').value = '';
  document.getElementById('d-dose').value = '';
}

function deleteDrugEntry(id) {
  if (!activeRecord) return;
  activeRecord.drugs = activeRecord.drugs.filter(d => d.id !== id);
  saveRecordsToStorage();
  renderDrugsTable();
}

function renderDrugsTable() {
  const tbody = document.getElementById('drugs-table-body');
  if (!tbody || !activeRecord) return;

  if (activeRecord.drugs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:#94A3B8; padding:16px;">No drugs logged yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = activeRecord.drugs.map(d => `
    <tr>
      <td>${d.time}</td>
      <td><strong>${d.name}</strong></td>
      <td>${d.dose}</td>
      <td><button class="btn-del" onclick="deleteDrugEntry(${d.id})">✕</button></td>
    </tr>
  `).join('');
}

// --- Fluid I/O Balance Engine ---
function calcIOBalance() {
  if (!activeRecord) return;
  const crys = parseFloat(activeRecord.ioCrys) || 0;
  const coll = parseFloat(activeRecord.ioColl) || 0;
  const blood = parseFloat(activeRecord.ioBlood) || 0;
  const ffp = parseFloat(activeRecord.ioFfp) || 0;
  const urine = parseFloat(activeRecord.ioUrine) || 0;
  const loss = parseFloat(activeRecord.ioLoss) || 0;

  const totalIn = crys + coll + blood + ffp;
  const totalOut = urine + loss;
  const net = totalIn - totalOut;

  const elem = document.getElementById('io-balance-display');
  if (elem) {
    elem.textContent = `${net >= 0 ? '+' : ''}${net} mL (In: ${totalIn} mL | Out: ${totalOut} mL)`;
    elem.style.color = net >= 0 ? 'var(--primary)' : 'var(--error)';
  }
}

// --- Official Hospital Record Summary Sheet ---
function renderSummarySheet() {
  const container = document.getElementById('summary-content');
  if (!container || !activeRecord) return;

  container.innerHTML = `
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px; margin-bottom:14px; font-size:0.9rem;">
      <div>
        <p><strong>Patient Name:</strong> ${activeRecord.name || 'N/A'}</p>
        <p><strong>Reg / Bed No:</strong> ${activeRecord.reg || 'N/A'}</p>
        <p><strong>Age / Sex:</strong> ${activeRecord.age}y / ${activeRecord.sex}</p>
        <p><strong>Weight / Height:</strong> ${activeRecord.weight} kg / ${activeRecord.height} cm (BMI: ${activeRecord.bmi})</p>
        <p><strong>ASA Physical Status:</strong> ${activeRecord.asa} (${activeRecord.urgency})</p>
      </div>
      <div>
        <p><strong>Diagnosis:</strong> ${activeRecord.diagnosis || 'N/A'}</p>
        <p><strong>Operation:</strong> ${activeRecord.operation || 'N/A'}</p>
        <p><strong>Surgeon:</strong> ${activeRecord.surgeon || 'N/A'}</p>
        <p><strong>Anesthesiologist:</strong> ${activeRecord.anesthesiologist || 'N/A'}</p>
        <p><strong>Date:</strong> ${activeRecord.date}</p>
      </div>
    </div>

    <div class="section-subtitle" style="border-bottom:1px solid #E2E8F0; padding-bottom:4px;">Pre-Op Investigations</div>
    <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:8px; font-size:0.82rem; margin-bottom:12px;">
      <div><strong>Hb:</strong> ${activeRecord.hb} g/dL</div>
      <div><strong>Platelets:</strong> ${activeRecord.platelet} k</div>
      <div><strong>Blood Group:</strong> ${activeRecord.bg}</div>
      <div><strong>RBS:</strong> ${activeRecord.rbs} mmol/L</div>
      <div><strong>S. Creatinine:</strong> ${activeRecord.creatinine} mg/dL</div>
      <div><strong>Electrolytes:</strong> ${activeRecord.electrolytes}</div>
      <div><strong>ECG:</strong> ${activeRecord.ecg}</div>
      <div><strong>CXR:</strong> ${activeRecord.cxr}</div>
    </div>

    <div class="section-subtitle" style="border-bottom:1px solid #E2E8F0; padding-bottom:4px;">Anesthesia Technique & Airway</div>
    <p style="font-size:0.85rem; margin-bottom:12px;">
      <strong>Technique:</strong> ${activeRecord.technique} | 
      ${activeRecord.technique.includes('GA') ? `ETT: ${activeRecord.ett} | Agent: ${activeRecord.inhalational} | Circuit: ${activeRecord.circuit}` : ''}
      ${activeRecord.technique.includes('Regional') ? `Block: ${activeRecord.regType} (${activeRecord.regSpace}) | Needle: ${activeRecord.regNeedle} | Local: ${activeRecord.regDrug}` : ''}
    </p>

    <div class="section-subtitle" style="border-bottom:1px solid #E2E8F0; padding-bottom:4px;">Intra-Operative Monitoring Chart</div>
    ${activeRecord.vitals.length > 0 ? `
      <table style="margin-bottom:14px;">
        <thead><tr><th>Time</th><th>BP</th><th>MAP</th><th>Pulse</th><th>SpO2</th><th>EtCO2</th></tr></thead>
        <tbody>${activeRecord.vitals.map(v => `<tr><td>${v.time}</td><td>${v.sys}/${v.dia}</td><td>${v.map}</td><td>${v.pulse}</td><td>${v.spo2}%</td><td>${v.etco2 || '--'}</td></tr>`).join('')}</tbody>
      </table>
    ` : '<p style="font-size:0.8rem; color:#888; margin-bottom:12px;">No intra-op vitals logged.</p>'}

    <div class="section-subtitle" style="border-bottom:1px solid #E2E8F0; padding-bottom:4px;">Medications Administered</div>
    ${activeRecord.drugs.length > 0 ? `
      <table style="margin-bottom:14px;">
        <thead><tr><th>Time</th><th>Drug Name</th><th>Dose & Route</th></tr></thead>
        <tbody>${activeRecord.drugs.map(d => `<tr><td>${d.time}</td><td><strong>${d.name}</strong></td><td>${d.dose}</td></tr>`).join('')}</tbody>
      </table>
    ` : '<p style="font-size:0.8rem; color:#888; margin-bottom:12px;">No medications logged.</p>'}

    <div class="section-subtitle" style="border-bottom:1px solid #E2E8F0; padding-bottom:4px;">Fluid Intake & Output Summary</div>
    <p style="font-size:0.85rem; margin-bottom:20px;">
      <strong>Intake:</strong> Crystalloids ${activeRecord.ioCrys} mL, Colloids ${activeRecord.ioColl} mL, Blood ${activeRecord.ioBlood} mL | 
      <strong>Output:</strong> Urine ${activeRecord.ioUrine} mL, Blood Loss ${activeRecord.ioLoss} mL | 
      <strong style="color:var(--primary);">Net Balance: ${document.getElementById('io-balance-display')?.textContent || '0 mL'}</strong>
    </p>

    <div style="display:flex; justify-content:space-between; margin-top:30px; padding-top:20px; border-top:1px dashed #CBD5E1; font-size:0.85rem;">
      <div>
        <p>__________________________</p>
        <p><strong>Surgeon's Signature</strong></p>
      </div>
      <div style="text-align:right;">
        <p>__________________________</p>
        <p><strong>Anesthesiologist's Signature</strong></p>
      </div>
    </div>
  `;
}

function shareCaseSummary() {
  if (!activeRecord) return;
  const summaryText = `*Anesthesia Aid - Case Record*\nPatient: ${activeRecord.name}\nAge/Sex: ${activeRecord.age}y/${activeRecord.sex}\nDiagnosis: ${activeRecord.diagnosis}\nOperation: ${activeRecord.operation}\nTechnique: ${activeRecord.technique}\nDate: ${activeRecord.date}`;
  if (navigator.share) {
    navigator.share({ title: 'Anesthesia Case Record', text: summaryText }).catch(() => {});
  } else {
    navigator.clipboard.writeText(summaryText);
    alert('Case summary copied to clipboard!');
  }
}

// --- Records List Rendering ---
function renderRecordsList() {
  const container = document.getElementById('records-container');
  if (!container) return;

  if (recordsList.length === 0) {
    container.innerHTML = `<div class="card" style="text-align:center; color:#94A3B8;">No records found. Create a new case above.</div>`;
    return;
  }

  container.innerHTML = recordsList.map(r => `
    <div class="record-card ${activeRecord && activeRecord.id === r.id ? 'active' : ''}" onclick="selectRecord('${r.id}')">
      <div>
        <div class="record-patient-name">${r.name || 'Unnamed Patient'}</div>
        <div class="record-meta">${r.age || '--'}y / ${r.sex || '--'} • ${r.operation || 'Surgery not specified'} • ${r.date}</div>
      </div>
      <div style="display:flex; align-items:center; gap:8px;">
        <span class="badge ${r.technique === 'GA' ? 'badge-approved' : 'badge-pending'}">${r.technique}</span>
        <button class="btn-del" title="Delete Case" onclick="deleteRecord('${r.id}', event)">✕</button>
      </div>
    </div>
  `).join('');
}

function filterRecords() {
  const q = document.getElementById('records-search')?.value.toLowerCase() || '';
  const container = document.getElementById('records-container');
  if (!container) return;

  const filtered = recordsList.filter(r => 
    (r.name && r.name.toLowerCase().includes(q)) ||
    (r.operation && r.operation.toLowerCase().includes(q)) ||
    (r.reg && r.reg.toLowerCase().includes(q))
  );

  container.innerHTML = filtered.map(r => `
    <div class="record-card ${activeRecord && activeRecord.id === r.id ? 'active' : ''}" onclick="selectRecord('${r.id}')">
      <div>
        <div class="record-patient-name">${r.name || 'Unnamed Patient'}</div>
        <div class="record-meta">${r.age}y / ${r.sex} • ${r.operation || 'Surgery'} • ${r.date}</div>
      </div>
      <button class="btn-del" onclick="deleteRecord('${r.id}', event)">✕</button>
    </div>
  `).join('');
}

// --- Export & Import JSON Engine ---
function exportAllRecords() {
  const blob = new Blob([JSON.stringify(recordsList, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `anesthesia_records_${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

function importRecords(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (event) => {
    try {
      const imported = JSON.parse(event.target.result);
      if (Array.isArray(imported) && imported.length > 0) {
        recordsList = imported;
        activeRecord = recordsList[0];
        saveRecordsToStorage();
        populateUIFromRecord(activeRecord);
        alert(`Successfully imported ${imported.length} cases!`);
      }
    } catch (err) {
      alert('Invalid JSON backup file.');
    }
  };
  reader.readAsText(file);
}

// --- Patient Modal Switching ---
function openPatientModal() {
  const modal = document.getElementById('patient-modal');
  const list = document.getElementById('modal-patient-list');
  if (list) {
    list.innerHTML = recordsList.map(r => `
      <div class="record-card ${activeRecord && activeRecord.id === r.id ? 'active' : ''}" onclick="selectRecord('${r.id}'); closePatientModalDirect();" style="margin-bottom:8px;">
        <div>
          <div class="record-patient-name">${r.name || 'Unnamed'}</div>
          <div class="record-meta">${r.age}y / ${r.sex} • ${r.technique}</div>
        </div>
      </div>
    `).join('');
  }
  if (modal) modal.classList.add('active');
}

function closePatientModal(e) {
  if (e.target.id === 'patient-modal') {
    closePatientModalDirect();
  }
}

function closePatientModalDirect() {
  document.getElementById('patient-modal')?.classList.remove('active');
}

// --- Doctor Account Modal ---
function showDoctorModal() {
  document.getElementById('doctor-modal')?.classList.add('active');
}

function closeDoctorModal(e) {
  if (e.target.id === 'doctor-modal') {
    closeDoctorModalDirect();
  }
}

function closeDoctorModalDirect() {
  document.getElementById('doctor-modal')?.classList.remove('active');
}

// --- Admin Panel Renderer ---
function renderAdminList() {
  const container = document.getElementById('admin-pending-list');
  if (!container) return;
  container.innerHTML = `
    <div style="border:1px solid #E2E8F0; border-radius:10px; padding:12px; margin-bottom:10px;">
      <p><strong>Dr. Tariqul Islam</strong> (A-84920)</p>
      <p style="font-size:0.8rem; color:#64748B;">Institute: DMCH | Session: 2022 | Phone: 01712345678</p>
      <p style="font-size:0.8rem; color:var(--primary); font-weight:700;">bKash TrxID: 9J87X1K9 (৳500 Trainee)</p>
      <div style="display:flex; gap:8px; margin-top:8px;">
        <button class="btn btn-primary btn-sm" onclick="alert('Doctor Approved!'); this.parentElement.parentElement.remove();">Approve Access</button>
        <button class="btn btn-danger btn-sm" onclick="this.parentElement.parentElement.remove();">Reject</button>
      </div>
    </div>
  `;
}
